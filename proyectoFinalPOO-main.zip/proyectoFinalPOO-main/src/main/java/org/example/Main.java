package org.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        new Tiendite();
        Scanner scan = new Scanner(System.in);
        boolean flag = true;
        String iguana = "Warning.txt";
       /* Tiendita.crearCliente("carlos","6682359422");
        Tiendita.crearCliente("linette","6682129013");
        Tiendita.crearCliente("marissa","6462396202");
        Tiendita.crearCliente("Juan", "6871679008");
        Tiendita.CrearProducto("Sabritas", 15, 10, "dulceria");
        Tiendita.CrearProducto("Papel de baño", 20.50, 20, "limpieza");
*/

//        do { //ciclo do para que el usuario decida cuando parar
//            System.out.println("1. Encriptar datos");
//            System.out.println("2. Desencriptar datos");
//            System.out.println("3. Salir");
//            System.out.println("Bienvenido, seleccione una de las acciones a realizar:");
//            int respuesta = scan.nextInt();
//            scan.nextLine();
//            String llave = manejoArchivo.LeerArchivo("Warning.txt");
//
//
//            switch (respuesta) {
//                case 1:
//                    System.out.println("Dame la frase a encriptar (Sin puntos aparte)"); //se le pide al usuario su frase
//                    String fraseEncriptar = scan.nextLine(); // se recibe la frase
//                    System.out.println(manejoArchivo.encriptar(fraseEncriptar, llave)); //llamado al metodo e imprime el resultado
//                    break;
//                case 2:
//                    System.out.println("Dame la frase a desencriptar (Sin puntos aparte)"); //se le pide la frase al usuario su frase
//                    String fraseDesencriptar = scan.nextLine(); // se recibe la frase
//                    System.out.println(manejoArchivo.desencriptar(fraseDesencriptar, llave)); // llamado al metodo e imprime el resultado
//                    break;
//                case 3:
//                    System.out.println("Gracias por utilizar mi programa"); // opcion para salir del usuario
//                    flag = false;
//                    break;
//                case 4:
//                    System.out.println(" !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~ÁÉÍÓÚáéíóúÜüÑñÇç");
//                    System.out.println(llave);
//                    break;
//                case 5:
//                    String b = manejoArchivo.LeerArchivo("Warning.txt");
//                    System.out.println(b);
//                    break;
//                default:
//                    System.out.println("Selecciona una opcion valida"); // opcion no posible
//                    break;
//            }
//        } while (flag);
//    }

//        while(flag) {
//            System.out.println("ELIGE UNA DE LAS SIGUIENTES OPCIONES");
//            System.out.println("1.Crear Cliente\n2.Eliminar Cliente\n3.Crear Producto\n4.mostrar clientes\n5.Mostrar productos\n6.Eliminar productos\n7.BuscarProductos");
//            int resp = scan.nextInt();
//            switch (resp) {
//                case 1:
//                    System.out.println("Dame tu nombre");
//                    scan.nextLine();
//                    String nombre = scan.nextLine();
//                    System.out.println("Dame tu numero de telefono");
//                    String numTel = scan.nextLine();
//                    int ll = Tiendita.crearCliente(nombre,numTel);
//                    System.out.println("Tu numero de cliente es: " + ll);
//                    break;
//                case 2:
//                    System.out.println("Dame el id del cliente a eliminar");
//                    scan.nextLine();
//                    int idCLiente = scan.nextInt();
//                    if (Tiendita.BuscarClientes(idCLiente) == null){
//                        System.out.println("El cliente no existe");
//                    } else {
//                        Tiendita.DarBajaCliente(idCLiente);
//                    }
//                    break;
//                case 3:
//                    System.out.println("Ingresa nombre del prodcuto: ");
//                    scan.nextLine();
//                    String producto= scan.nextLine();
//
//                    if (Tiendita.BuscarProductoNombre(producto)!=null){
//                        System.out.println("El producto ya existe.");
//                    }else{
//                        System.out.println("ingresa Precio:");
//                        double precio = scan.nextDouble();
//                        System.out.println("Ingrese existencia:");
//                        int esi = scan.nextInt();
//                        scan.nextLine();
//                        System.out.println("ingrese tipo:");
//                        String TIPO= scan.nextLine();
//                        Tiendita.CrearProducto(producto,precio,esi,TIPO);
//                    }
//                    break;
//                    //hola carlos que tal
//                case 4:
//                    Tiendita.showClientes(Tiendita.getClienteslista());
//                    break;
//                case 5:
//                    System.out.println(Tiendita.showProductos(Tiendita.getProductolista()));
//                    break;
//                case 6:
//                    System.out.println("Dame el id del producto a eliminar");
//                    scan.nextLine();
//                    String codPro = scan.nextLine();
//                    if(Tiendita.BuscarProducto(codPro) == null){
//                        System.out.println("El cliente no existe");
//                    }else{
//                        Tiendita.DarBajaProducto(codPro);
//                    }
//                    break;
//                case 7:
//                    System.out.println("Ingresa el codigo a buscar: ");
//                    scan.nextLine();
//                    String resp1 = scan.nextLine();
//                    Producto p = Tiendita.BuscarProducto(resp1);
//                    if (p!=null){
//                        System.out.println(p.nombreP);
//                    }else {
//                        System.out.println("producto no existe");
//                    }
//                    break;
//                case 8:
//                    manejoArchivo.
//                    break;
//                default:
//                    flag = false;
//                    break;
//            }
//        }
//    }
    }
}

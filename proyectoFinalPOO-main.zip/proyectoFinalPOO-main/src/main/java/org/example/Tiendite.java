package org.example;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class Tiendite extends JFrame{
    private JPanel tiendita;
    private JButton INICIARSESIONButton;
    private JButton CREARCUENTAButton;
    private JLabel Logo;
    private JLabel titulo;
    private JPasswordField contrasena;
    private JTextField textField1;
    private JLabel Registrarse;
    private JButton verPass;
    private static String OperadoresFile = "Operadores.txt";
    private static String Iguana = "Warning.txt";
    private static String idUsus;

    public static String getIdUsus() {
        return idUsus;
    }

    public static void setIdUsus(String idUsus) {
        Tiendite.idUsus = idUsus;
    }

    public static String getIguana() {
        return Iguana;
    }

    public static void setIguana(String iguana) {
        Iguana = iguana;
    }

    public static String getOperadoresFile() {
        return OperadoresFile;
    }

    public void setOperadoresFile(String operadoresFile) {
        OperadoresFile = operadoresFile;
    }

    public Tiendite(){
        setVisible(true);
        setTitle("Abarrotes Guzmán");
        String icono = "src/main/resources/contenido/Abarrotes (1).jpg";
        setSize(550,500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setContentPane(tiendita);
        setLocationRelativeTo(null);
        setResizable(false);
        ImageIcon logoOriginal = new ImageIcon(icono);
        Image imagenOriginal = logoOriginal.getImage();
        setIconImage(imagenOriginal);
        int anchoDeseado = 250;
        int altoDeseado = 250;
        Image imagenRedimensionada = imagenOriginal.getScaledInstance(anchoDeseado, altoDeseado, Image.SCALE_AREA_AVERAGING);
        ImageIcon logoRedimensionado = new ImageIcon(imagenRedimensionada);
        Logo.setVisible(true);
        Logo.setIcon(logoRedimensionado);
        Border normalBorder = Registrarse.getBorder();
        Color cafe = new Color(102, 51, 0); // RGB para el café
        LineBorder bordeCafe = new LineBorder(cafe, 2); // Grosor del borde: 2 pixels
        ImageIcon ojo = new ImageIcon("src/main/resources/Ojo.png");
        Image ojoOr = ojo.getImage();
        Image OjoRed = ojoOr.getScaledInstance(20, 20, Image.SCALE_SMOOTH);
        ImageIcon ojoRed = new ImageIcon(OjoRed);
        verPass.setIcon(ojoRed);
        ImageIcon ojoCerr = new ImageIcon("src/main/resources/ojoCerrado.png");
        Image ojoCerra = ojoCerr.getImage();
        Image OjoCerrado = ojoCerra.getScaledInstance(20,20,Image.SCALE_SMOOTH);
        ImageIcon OCerr = new ImageIcon(OjoCerrado);
        contrasena.setDocument(new NoSpaceDocument());
        textField1.setDocument(new NoNada());


        INICIARSESIONButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (!textField1.getText().isEmpty()&& contrasena.getPassword().length !=0 ){
                    boolean existe = manejoArchivo.buscarOperadorEnFile(Tiendite.getOperadoresFile(),"ID: "+textField1.getText());
                    if (existe){

                        String m = manejoArchivo.encriptar(new String(contrasena.getPassword()),manejoArchivo.LeerArchivoWa(Tiendite.getIguana()));

                        String b= "ID: "+textField1.getText() +", CONTRASEÑA: "+ m;
                        if (manejoArchivo.buscarEnFile(Tiendite.getOperadoresFile(),b)){
                            idUsus = textField1.getText();
                            new menu();
                            dispose();
                        }else {
                            JOptionPane.showMessageDialog(null,"Contraseña Incorrecta.");
                        }
                    }else {
                        JOptionPane.showMessageDialog(null,"El usuario ingresado no existe.");
                    }
                }else {
                    JOptionPane.showMessageDialog(null,"Favor de llenar todos los espacios.", "ERROR", JOptionPane.ERROR_MESSAGE);
                }


//                new menu();
//                dispose();

            }
        });

        //Linette romina
//juan pablo
        verPass.addActionListener(new ActionListener() {
            boolean visible = false;
            @Override
            public void actionPerformed(ActionEvent e) {
                visible = !visible;
                if (visible) {
                    contrasena.setEchoChar((char) 0); // Muestra la contraseña
                    verPass.setIcon(OCerr);
                } else {
                    contrasena.setEchoChar('\u2022'); // Restaura el campo de contraseña
                    verPass.setIcon(ojoRed);
                }
            }
        });

        Registrarse.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
               new crearcuenta(Tiendite.this);
                dispose();
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {
                Border highlightBorder = new LineBorder(bordeCafe.getLineColor());
                Registrarse.setBorder(highlightBorder);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                Registrarse.setBorder(normalBorder);
                Registrarse.setBackground(null);
                Registrarse.setOpaque(false);
            }
        });
    }

    private static class NoSpaceDocument extends javax.swing.text.PlainDocument {
        @Override
        public void insertString(int offs, String str, AttributeSet a) throws BadLocationException {
            if (str != null && !str.contains(" ")) { // No permite espacios
                super.insertString(offs, str, a);
            }
        }
    }

    private static class NoNada extends javax.swing.text.PlainDocument {
        @Override
        public void insertString(int offs, String str, AttributeSet a) throws BadLocationException {
            if (str != null && !str.matches(".*[a-zA-Z].*") && !str.contains(" ") && !str.matches(".*[^a-zA-Z0-9].*")) {
                super.insertString(offs, str, a);
            }
        }
    }
}

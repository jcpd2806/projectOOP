package org.example;

public abstract class Solicitudes {
    protected int cantidad;
    protected double precio;
    protected String codigoProd;

    public Solicitudes(int cantidad, double precio, String codigoProd) {
        this.cantidad = cantidad;
        this.precio = precio;
        this.codigoProd = codigoProd;
    }

    public abstract void atender(Tiendita tiendia);

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getCodigoProd() {
        return codigoProd;
    }

    public void setCodigoProd(String codigoProd) {
        this.codigoProd = codigoProd;
    }


}

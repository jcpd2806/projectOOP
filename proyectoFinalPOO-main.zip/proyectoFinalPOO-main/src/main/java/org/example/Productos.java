package org.example;

public class Productos<T>{
    private static lista<Dulceria> dulcerialista;
    private static lista<Alacena> alacenalista;
    private static lista<Lacteos> lacteoslista;
    private static lista<Frescos> frescoslista;
    private static lista<Bebidas> bebidaslista;
    private static lista<Limpieza> limpiezalista;
    private static lista<Botana> botanalista;
}

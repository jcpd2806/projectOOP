package org.example;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Arrays;

public class crearcuenta extends JFrame {


    private JPanel crearcuenta;
    private JTextField textField1;
    private JPasswordField passwordField1;
    private JPasswordField passwordField2;
    private JButton listoButton;
    private JButton passVerButton;

    public crearcuenta(Tiendite tiendite){
        setVisible(true);
        setContentPane(crearcuenta);
        setSize(550,500);
        setLocationRelativeTo(null);
        setTitle("Crear cuenta");
        String icono = "src/main/resources/contenido/Abarrotes (1).jpg";
        ImageIcon logoOriginal = new ImageIcon(icono);
        Image imagenOriginal = logoOriginal.getImage();
        setIconImage(imagenOriginal);
        setResizable(false);
        textField1.setDocument(new NoNada());
        passwordField1.setDocument(new NoSpaceDocument());
        passwordField2.setDocument(new NoSpaceDocument());
        ImageIcon ojo = new ImageIcon("src/main/resources/Ojo.png");
        Image ojoOr = ojo.getImage();
        Image OjoRed = ojoOr.getScaledInstance(20, 20, Image.SCALE_SMOOTH);
        ImageIcon ojoRed = new ImageIcon(OjoRed);
        passVerButton.setIcon(ojoRed);
        ImageIcon ojoCerr = new ImageIcon("src/main/resources/ojoCerrado.png");
        Image ojoCerra = ojoCerr.getImage();
        Image OjoCerrado = ojoCerra.getScaledInstance(20,20,Image.SCALE_SMOOTH);
        ImageIcon OCerr = new ImageIcon(OjoCerrado);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                tiendite.setVisible(true);
            }
        });

        listoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (!textField1.getText().isEmpty() && passwordField1.getPassword().length !=0 &&
                        passwordField2.getPassword().length !=0) {
                    boolean existe = manejoArchivo.buscarOperadorEnFile(Tiendite.getOperadoresFile(),"ID: "+textField1.getText());
                    if (!existe){
                        if (Arrays.equals(passwordField1.getPassword(), passwordField2.getPassword())){
                            String m = manejoArchivo.encriptar(new String(passwordField1.getPassword()),manejoArchivo.LeerArchivoWa(Tiendite.getIguana()));

                            String info = "ID: " + textField1.getText() + ", CONTRASEÑA: " + m;
                            manejoArchivo.EscribirArchivo(Tiendite.getOperadoresFile(), info);
                            setVisible(false);
                            tiendite.setVisible(true);
                        }else {
                            JOptionPane.showMessageDialog(null,"Las contraseñas ingresadas no coinciden.");
                        }
                    }else {
                        JOptionPane.showMessageDialog(null,"El ID ingresa ya se encuentra registrado.");
                    }

                } else {
                    JOptionPane.showMessageDialog(null,"Alguno de los campos está vacío.");
                }




            }
        });

        passVerButton.addActionListener(new ActionListener() {
            boolean visible = false;
            @Override
            public void actionPerformed(ActionEvent e) {
                visible = !visible;
                if (visible) {
                    passwordField1.setEchoChar((char) 0); // Muestra la contraseña
                    passwordField2.setEchoChar((char) 0);
                    passVerButton.setIcon(OCerr);
                } else {
                    passwordField1.setEchoChar('\u2022');// Restaura el campo de contraseña
                    passwordField2.setEchoChar('\u2022');
                    passVerButton.setIcon(ojoRed);
                }
            }
        });

    }
    private static class NoSpaceDocument extends javax.swing.text.PlainDocument {
        @Override
        public void insertString(int offs, String str, AttributeSet a) throws BadLocationException {
            if (str != null && !str.contains(" ")) { // No permite espacios
                super.insertString(offs, str, a);
            }
        }
    }

    private static class NoNada extends javax.swing.text.PlainDocument {
        @Override
        public void insertString(int offs, String str, AttributeSet a) throws BadLocationException {
            if (str != null && !str.matches(".*[a-zA-Z].*") && !str.contains(" ")) {
                super.insertString(offs, str, a);
            }
        }
    }
}

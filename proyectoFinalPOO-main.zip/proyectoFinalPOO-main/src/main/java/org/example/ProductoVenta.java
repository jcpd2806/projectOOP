package org.example;

public class ProductoVenta {
    protected String nombreP;
    protected String codigoP;
    protected int existenciaP;
    protected double precioP;

    public ProductoVenta(String nombreP, String codigoP, int existenciaP, double precioP) {
        this.nombreP = nombreP;
        this.codigoP = codigoP;
        this.existenciaP = existenciaP;
        this.precioP = precioP;
    }

    public String getNombreP() {
        return nombreP;
    }

    public void setNombreP(String nombreP) {
        this.nombreP = nombreP;
    }

    public String getCodigoP() {
        return codigoP;
    }

    public void setCodigoP(String codigoP) {
        this.codigoP = codigoP;
    }

    public int getExistenciaP() {
        return existenciaP;
    }

    public void setExistenciaP(int existenciaP) {
        this.existenciaP += existenciaP;
    }

    public double getPrecioP() {
        return precioP;
    }

    public void setPrecioP(double precioP) {
        this.precioP = precioP;
    }

    public String toString(){
        return nombreP;
    }
}

package org.example;

public class Devoluciones extends Solicitudes{

    public Devoluciones(int cantidad, double precio, String codigoProd) {
        super(cantidad, precio, codigoProd);
    }

    @Override
    public void atender(Tiendita tiendita) {

    }

}

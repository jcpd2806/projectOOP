package org.example;

public class Ventas {
    private Clientes cliente;
    private int idProducto;
    private double monto;
    private String fecha;

    public Ventas(Clientes cliente, int idProducto, double monto, String fecha) {
        this.cliente = cliente;
        this.idProducto = idProducto;
        this.monto = monto;
        this.fecha = fecha;
    }

    // Getters y setters
    public Clientes getCliente() {
        return cliente;
    }

    public void setCliente(Clientes cliente) {
        this.cliente = cliente;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
}

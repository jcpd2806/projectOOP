package org.example;

public class Dulceria extends Producto{

    public Dulceria(String nombreP, String codigoP, int existenciaP, double precioP) {
        super(nombreP, codigoP, existenciaP, precioP);
    }

}

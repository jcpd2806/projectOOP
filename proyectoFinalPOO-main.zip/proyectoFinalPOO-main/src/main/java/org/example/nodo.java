package org.example;

public class nodo<T> {
    private T dato;
    private nodo<T> siguiente;

    //constructor primero y final
    public nodo(T dato){
        this.dato = dato;
        siguiente = null;
    }
    //constructor con apuntador
    /*
   public nodo(T dato, nodo<T> siguiente){
        this.dato = dato;
        this.siguiente = siguiente;
    }*/

    public T getDato() {
        return dato;
    }

    public nodo<T> getSiguiente() {
        return siguiente;
    }

    public void setDato(T dato) {
        this.dato = dato;
    }

    public void setSiguiente(nodo<T> siguiente) {
        this.siguiente = siguiente;
    }

    public void enlazarNodo(nodo<T> n){
        siguiente = n;
    }
}

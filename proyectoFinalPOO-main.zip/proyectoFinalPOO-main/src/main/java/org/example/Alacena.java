package org.example;

public class Alacena extends Producto{
    public Alacena(String nombreP, String codigoP, int existenciaP, double precioP) {
        super(nombreP, codigoP, existenciaP, precioP);
    }

}

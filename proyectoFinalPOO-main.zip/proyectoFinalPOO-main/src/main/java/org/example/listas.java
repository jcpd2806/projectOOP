package org.example;

public interface listas<T>{
    void Adicionar(T dato);
    void insertar(T dato, int indice);
    T obtener(int indice);
    boolean isEmpty();
    void eliminar(int indice);
    int longitud();
    int buscar(T dato);
    void imprimirNodos();
}

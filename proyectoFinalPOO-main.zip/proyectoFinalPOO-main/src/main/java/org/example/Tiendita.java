package org.example;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import javax.swing.*;
import java.awt.*;
import java.util.Objects;

public class Tiendita {
   private static lista<Clientes> clienteslista;
   private static lista<Producto> productolista;
   private static int contadorCliente;
   private static int contadorCodigo;
   private static String ProductosFile = "Productos.txt";
   private static String ClientesFile = "Clientes.txt";
   private static String ventasFile = "ventas.txt";
   private static String devolFile = "Devoluciones.txt";
   private static double saldo;

   static {
      clienteslista = new lista<>();
      productolista = new lista<>();
      contadorCliente = 1000;
      contadorCodigo = 1000;
      saldo= 1000;
   }



   public static String getDevolFile() {
      return devolFile;
   }

   public static void setVentasFile(String ventasFile) {
      Tiendita.ventasFile = ventasFile;
   }

   public static void setDevolFile(String devolFile) {
      Tiendita.devolFile = devolFile;
   }

   public static String getClientesFile() {
      return ClientesFile;
   }

   public static void setClientesFile(String clientesFile) {
      ClientesFile = clientesFile;
   }

   public static String getProductosFile() {
      return ProductosFile;
   }
   public static String getVentasFile(){return ventasFile;}


   public static void setProductosFile(String productosFile) {
      ProductosFile = productosFile;
   }
   public static lista<Clientes> getClienteslista() {
      return clienteslista;
   }

   public static void setClienteslista(lista<Clientes> clienteslista) {
      Tiendita.clienteslista = clienteslista;
   }

   public static lista<Producto> getProductolista() {
      return productolista;
   }

   public static void setProductolista(lista<Producto> productolista) {
      Tiendita.productolista = productolista;
   }

   public static double getSaldo() {
      return saldo;
   }

   public static void setSaldo(double saldo) {
      Tiendita.saldo = saldo;
   }

   public static int getContadorCodigo() {
      return contadorCodigo;
   }

   public static void setContadorCodigo(int contadorCodigo) {
      Tiendita.contadorCodigo = contadorCodigo;
   }

   public static int getContadorCliente() {
      return contadorCliente;
   }

   public static void setContadorCliente(int contadorCliente) {
      Tiendita.contadorCliente = contadorCliente;
   }

   public static void deposito(double venta){
      if (venta <= 0){
         JOptionPane.showMessageDialog(null,"Ingresa cantidad valida");
      } else {
         saldo += venta;
//         JOptionPane.showMessageDialog(null,"bien");
      }
   }

   public static void devolucion(double devolucion){
      if (saldo >= devolucion && devolucion >= 0){
         saldo -= devolucion;
         JOptionPane.showMessageDialog(null,"bien");
      } else {
         JOptionPane.showMessageDialog(null,"Ingresa cantidad valida");
      }
   }

   public static int crearCliente(String nombreC, String numTel) {
      int idCliente = ++contadorCliente;
      double puntos = 0;
      Clientes c = new Clientes(idCliente, nombreC, numTel, puntos);
      clienteslista.Adicionar(c);
      return idCliente;
   }

   public static Clientes BuscarClientes(int idCliente) {
      nodo<Clientes> temp = clienteslista.getCabeza();
      while (temp != null) {
         if (temp.getDato().getIdCliente() == idCliente) {
            int pos = clienteslista.buscar(temp.getDato());
            return clienteslista.obtener(pos);
         }
         temp = temp.getSiguiente();
      }
      return null;
   }

   public static Clientes BuscarClientesNum(String num) {
      nodo<Clientes> temp = clienteslista.getCabeza();
      while (temp != null) {
         if (Objects.equals(temp.getDato().getNumTel(), num)) {
            int pos = clienteslista.buscar(temp.getDato());
            return clienteslista.obtener(pos);
         }
         temp = temp.getSiguiente();
      }
      return null;
   }


   public static Producto BuscarProducto(String codProd) {
      nodo<Producto> temp = productolista.getCabeza();
      while (temp != null) {
         if (Objects.equals(temp.getDato().getCodigoP(), codProd)) {
            int pos = productolista.buscar(temp.getDato());
            return productolista.obtener(pos);
         }
         temp = temp.getSiguiente();
      }
      return null;
   }

   public static Producto BuscarProductoNombre(String nombre) {
      nodo<Producto> temp = productolista.getCabeza();
      while (temp != null) {
         if (Objects.equals(temp.getDato().getNombreP(), nombre)) {
            int pos = productolista.buscar(temp.getDato());
            return productolista.obtener(pos);
         }
         temp = temp.getSiguiente();
      }
      return null;
   }


   public static int DarBajaCliente(int idCliente) {
      Clientes c = BuscarClientes(idCliente);
      if (c != null) {
         int pos = clienteslista.buscar(c);
         clienteslista.eliminar(pos);
         return idCliente;
      } else {
         return -1;
      }
   }

   public static void DarBajaProducto(String codProd) {
      Producto p = BuscarProducto(codProd);
      if (p != null) {
         int pos = productolista.buscar(p);
         productolista.eliminar(pos);
         System.out.println("El producto: " + codProd + " eliminado exitosamente");
      }
   }

   public static String CrearProducto(String nombreP, double precioP, int existeciaP, String tipo) {

      int codigo = ++contadorCodigo;
      String cod = String.valueOf(codigo);
      String codigofin="jhjhjh";
      switch (tipo) {
         case "Dulcería":
            codigofin = "d" + cod;
            Producto dulceria = new Dulceria(nombreP, codigofin, existeciaP, precioP);
            productolista.Adicionar(dulceria);
            break;
         case "Botana":
            codigofin = "bo" + cod;
            Producto botana = new Botana(nombreP, codigofin, existeciaP, precioP);
            productolista.Adicionar(botana);
            break;
         case "Bebidas":
            codigofin = "be" + cod;
            Producto bebidas = new Bebidas(nombreP, codigofin, existeciaP, precioP);
            productolista.Adicionar(bebidas);
            break;
         case "Alacena":
            codigofin = "a" + cod;
            Producto alacena = new Alacena(nombreP, codigofin, existeciaP, precioP);
            productolista.Adicionar(alacena);
            break;
         case "Frescos":
            codigofin = "f" + cod;
            Producto frescos = new Frescos(nombreP, codigofin, existeciaP, precioP);
            productolista.Adicionar(frescos);
            break;
         case "Lácteos":
            codigofin = "la" + cod;
            Producto lacteos = new Lacteos(nombreP, codigofin, existeciaP, precioP);
            productolista.Adicionar(lacteos);
            break;
         case "Limpieza":
            codigofin = "li" + cod;
            Producto limpieza = new Limpieza(nombreP, codigofin, existeciaP, precioP);
            productolista.Adicionar(limpieza);
            break;
         default:
            break;
      }
   return codigofin;
   }

   public static lista<ProductoVenta> leerProductosDesdeArchivo() {
      lista<ProductoVenta> productos = new lista<>();
      try (BufferedReader br = new BufferedReader(new FileReader("Productos.txt"))) {
         String line;
         while ((line = br.readLine()) != null) {
            // Divide la línea en partes usando ", " como separador
            String[] partes = line.split(", ");
            // Verifica si la línea tiene al menos 5 partes
            if (partes.length >= 3) {
               String nombre = partes[0].split(": ")[1];
               String cod = partes[1].split(": ")[1];
               double precio = Double.parseDouble(partes[2].split(": ")[1]);
               int existencia = Integer.parseInt(partes[3].split(": ")[1]);
               //String tipo = partes[4].split(": ")[1];
               productos.Adicionar(new ProductoVenta(nombre, cod, existencia, precio));
            } else {
               System.err.println("Línea malformada: " + line);
            }
         }
      } catch (IOException e) {
         e.printStackTrace();
      }
      return productos;
   }

   public static String getFileProductos(){
      return "Productos.txt";
   }

   public static String showClientes(lista<Clientes> clienteslista) {
      if (clienteslista.isEmpty()) {
         System.out.println("La lista esta vacia");
      } else {
         System.out.println("Lista Clientes: ");
         for (int i = 0; i < clienteslista.getTamanio(); i++) {
            Clientes clientes = clienteslista.obtener(i);
            System.out.println("ID Cliente: " + clientes.getIdCliente());
            System.out.println("Nombre: " + clientes.getNombreC());
            System.out.println("Numero Telefono: " + clientes.getNumTel());
            System.out.println("Numero Puntos: " + clientes.getPuntos());
            System.out.println("\n");
         }
      }
      return null;
   }

   public static String showProductos(lista<Producto> productolista) {
      boolean sinS = false;
      if (productolista.isEmpty()) {
         return "No hay productos registrados";
      } else {
         StringBuilder listaProd = new StringBuilder();
         listaProd.append("Lista productos: ").append("\n");
         StringBuilder listaOut = new StringBuilder();
         listaOut.append("Productos sin stock: ").append("\n");
         for (int i = 0; i < productolista.getTamanio(); i++) {
            Producto producto = productolista.obtener(i);
            if (producto.getExistenciaP() > 0) {
               listaProd.append("Codigo del producto: ").append(producto.getCodigoP()).append("\n");
               listaProd.append("Nombre del producto: ").append(producto.getNombreP()).append("\n");
               listaProd.append("Total en existencia: ").append(producto.getExistenciaP()).append("\n");
               listaProd.append("Precio: ").append(producto.getPrecioP()).append("\n");
               listaProd.append("\n");
            } else {
               sinS = true;
               listaOut.append("Codigo del producto: ").append(producto.getCodigoP()).append("\n");
               listaOut.append("Nombre del producto: ").append(producto.getNombreP()).append("\n");
               listaOut.append("Precio: ").append(producto.getPrecioP()).append("\n");
               listaOut.append("\n");
            }

         }
         if(sinS) {
            listaProd.append(listaOut);
            return listaProd.toString();
         }else{
            return listaProd.toString();
         }
      }
   }

   public static String fecha() {
      LocalDate now = LocalDate.now();
      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
      String formattedDateTime = now.format(formatter);
      return formattedDateTime;
   }
}

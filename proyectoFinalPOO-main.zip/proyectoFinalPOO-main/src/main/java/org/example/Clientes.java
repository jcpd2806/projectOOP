package org.example;

import javax.swing.*;

public class Clientes {
    /*private static int idCliente;
    private static String nombreC;
    private static String numTel;
    private static double puntos;
    */
    private  int idCliente;
    private  String nombreC;
    private  String numTel;
    private  double puntos;
    public Clientes(int idCliente, String nombreC, String numTel, double puntos) {
        this.idCliente = idCliente;
        this.nombreC = nombreC;
        this.numTel = numTel;
        this.puntos = puntos;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public String getNombreC() {
        return nombreC;
    }

    public void setNombreC(String nombreC) {
        this.nombreC = nombreC;
    }

    public String getNumTel() {
        return numTel;
    }

    public void setNumTel(String numTel) {
        this.numTel = numTel;
    }

    public double getPuntos() {
        return puntos;
    }

    public void setPuntos(double puntos) {
        this.puntos = puntos;
    }

    public  void deposito(double venta){
        if (venta <= 0){
            JOptionPane.showMessageDialog(null,"Ingresa cantidad valida");
        } else {
            this.puntos += venta;
//         JOptionPane.showMessageDialog(null,"bien");
        }
    }

    public  void devolucion(double devolucion){
        if (this.puntos >= devolucion && devolucion >= 0){
            this.puntos -= devolucion;
            JOptionPane.showMessageDialog(null,"bien");
        } else {
            JOptionPane.showMessageDialog(null,"Ingresa cantidad valida");
        }
    }
}

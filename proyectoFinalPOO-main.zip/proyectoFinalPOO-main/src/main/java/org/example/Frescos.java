package org.example;

public class Frescos extends Producto{
    public Frescos(String nombreP, String codigoP, int existenciaP, double precioP) {
        super(nombreP, codigoP, existenciaP, precioP);
    }

}

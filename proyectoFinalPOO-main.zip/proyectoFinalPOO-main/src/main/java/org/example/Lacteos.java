package org.example;

public class Lacteos extends Producto{
    public Lacteos(String nombreP, String codigoP, int existenciaP, double precioP) {
        super(nombreP, codigoP, existenciaP, precioP);
    }

}

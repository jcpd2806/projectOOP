package org.example;
import java.io.*;
import java.security.SecureRandom;
import java.util.List;
import java.util.Objects;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class manejoArchivo {
    /*
    public static String LeerArchivo(String filepath)
    {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(filepath));
            String linea;
            while ((linea = reader.readLine()) != null) {
                System.out.println(linea);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return filepath;
    }


     */


    public static String LeerArchivoWa(String filepath) {
        StringBuilder contenido = new StringBuilder();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(filepath));
            String linea;
            int contador = 0;
            while ((linea = reader.readLine()) != null) {
                if (linea.contains("Ç|;B}_0")){
                    return linea;
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return contenido.toString();
    }

    public static String llaveAleatoria() { //Se crea una llave aleatoria
        String variables = " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~ÁÉÍÓÚáéíóúÜüÑñÇç";
        SecureRandom random = new SecureRandom();
        StringBuilder builder = new StringBuilder();

        char[] llave = variables.toCharArray();
        for (int i = llave.length - 1; i > 0; i--) { //se utiliza ciclo for para mezclar el contenido del string variable
            int indice = random.nextInt(i + 1);
            char otraLlave = llave[i];
            llave[i] = llave[indice];
            llave[indice] = otraLlave;
        }
        for (char c : llave) {
            builder.append(c);
        }
        return
                builder.toString(); //se regresa la clave a String
    }

    public static String encriptar(String texto, String clave) {
        String variables = " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~ÁÉÍÓÚáéíóúÜüÑñÇç";
        StringBuilder encriptado = new StringBuilder();

        for (char c : texto.toCharArray()) { // Convierte la frase en array
            int index = variables.indexOf(c); // Busca la posición en variables de cada carácter
            if (index != -1) {
                encriptado.append(clave.charAt(index)); // Usa la clave para encriptar el carácter
            } else {
                encriptado.append(c); // Si el carácter no está en variables, se agrega tal cual
            }
        }
        return encriptado.toString(); // Regresa el cifrado a string
    }

    public static String desencriptar(String encriptado, String clave) {
        String variables = " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~ÁÉÍÓÚáéíóúÜüÑñÇç";
        StringBuilder desencriptado = new StringBuilder();

        for (char c : encriptado.toCharArray()) { // Convierte la frase en array
            int index = clave.indexOf(c); // Busca la posición en la clave de cada carácter
            if (index != -1) {
                desencriptado.append(variables.charAt(index)); // Usa variables para desencriptar el carácter
            } else {
                desencriptado.append(c); // Si el carácter no está en la clave, se agrega tal cual
            }
        }
        return desencriptado.toString(); // Regresa a string la frase
    }

    public static void EscribirArchivo1(String filepath, String message)
    {
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(filepath,true));
            writer.write(message+"\n");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static boolean Novacio(String filepath){
        File file = new File(filepath);
        return file.length()!=0;
    }



    public static String leerArchivo(String filepath) {
        StringBuilder contenido = new StringBuilder();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(filepath));
            String linea;
            while ((linea = reader.readLine()) != null) {
                contenido.append(linea).append("\n");
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return contenido.toString();
    }

    public static String leerArchivoCliente(String filepath, String idCliente){
        StringBuilder cont= new StringBuilder();
        try {
            BufferedReader reader= new BufferedReader(new FileReader(filepath));
            String linea;
            while ((linea = reader.readLine()) != null) {
                if (linea.contains("Cliente: "+idCliente)){
                    cont.append(linea).append("\n");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return cont.toString();
    }

    public static boolean buscarEnFile(String filepath, String busqueda){
        try {
            BufferedReader reader= new BufferedReader(new FileReader(filepath));
            String linea;
            while ((linea = reader.readLine()) != null) {
                if (linea.equals(busqueda)){
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static void EscribirArchivo(String filepath, String message)
    {
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(filepath,true));
            writer.write(message+"\n");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void ExtreaerClientes(String filepath){

        try (BufferedReader br = new BufferedReader(new FileReader(filepath))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] parts = line.split(", ");

                String nombre = parts[0].split(": ")[1];
                int id = Integer.parseInt(parts[1].split(": ")[1]);
                String numeroCelular = parts[2].split(": ")[1];
                double puntos= Double.parseDouble(parts[3].split(": ")[1]);
                int idddd= Tiendita.crearCliente(nombre, numeroCelular);
                Clientes cl= Tiendita.BuscarClientesNum(numeroCelular);
                cl.setIdCliente(id);
                cl.setPuntos(puntos);
                if (id > Tiendita.getContadorCliente()) {
                    Tiendita.setContadorCliente(id);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void ExtreaerProductos(String filepath){

        try (BufferedReader br = new BufferedReader(new FileReader(filepath))) {
            String line, idddd = "tilín";
            while ((line = br.readLine()) != null) {

                if (line.trim().isEmpty()) continue;

                String[] parts = line.split(", ");

                // Separar la línea en los diferentes atributos
                String nombre = parts[0].split(": ")[1];
                String id = parts[1].split(": ")[1];
                double precio = Double.parseDouble(parts[2].split(": ")[1]);
                int Existencia = Integer.parseInt(parts[3].split(": ")[1]);
                //String Tipo = parts[4].split(": ")[1];
                if (id.contains("bo")){
                     idddd= Tiendita.CrearProducto(nombre,precio,Existencia,"Botana");
                }else if (id.contains("li")){
                    idddd= Tiendita.CrearProducto(nombre,precio,Existencia,"Limpieza");
                }else if (id.contains("la")){
                    idddd= Tiendita.CrearProducto(nombre,precio,Existencia,"Lácteos");
                }else if (id.contains("f")){
                    idddd= Tiendita.CrearProducto(nombre,precio,Existencia,"Frescos");
                }else if (id.contains("a")){
                    idddd= Tiendita.CrearProducto(nombre,precio,Existencia,"Alacena");
                }else if (id.contains("be")){
                    idddd= Tiendita.CrearProducto(nombre,precio,Existencia,"Bebidas");
                }else if (id.contains("d")){
                    idddd= Tiendita.CrearProducto(nombre,precio,Existencia,"Dulcería");
                }
                Producto producto= Tiendita.BuscarProductoNombre(nombre);
                producto.setCodigoP(id);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void escribirVenta(String filepath, String ventaText, double total, String clienteInfo) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filepath, true))) {
            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String fechaHora = now.format(formatter);

            writer.write("Fecha y Hora: " + fechaHora + "\n");
            if (clienteInfo != null && !clienteInfo.isBlank()) {
                writer.write("Cliente: " + clienteInfo + "\n");
            }
            writer.write(ventaText + "\n");
            writer.write("Total: " + total + "\n");
            writer.write("-------------------------------\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void escribirDevolucion(String filepath, String devolucionText, double total) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filepath, true))) {
            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String fechaHora = now.format(formatter);

            writer.write("Fecha y Hora: " + fechaHora + "\n");
            writer.write(devolucionText + "\n");
            writer.write("Total: " + total + "\n");
            writer.write("-------------------------------\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static lista<String> buscarVentasPorFecha(String filepath, String fecha) {
        lista<String> ventas = new lista<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filepath))) {
            String linea;
            boolean esVentaDeFecha = false;
            StringBuilder ventaActual = new StringBuilder();

            while ((linea = reader.readLine()) != null) {
                if (linea.startsWith("Fecha y Hora:")) {
                    String fechaVenta = linea.substring(14, 24); // Extraer la fecha sin la hora
                    if (fechaVenta.equals(fecha)) {
                        esVentaDeFecha = true;
                        ventaActual.setLength(0); // Reiniciar el StringBuilder para una nueva venta
                        ventaActual.append(linea).append("\n");
                    } else {
                        esVentaDeFecha = false;
                    }
                } else if (esVentaDeFecha) {
                    ventaActual.append(linea).append("\n");
                    if (linea.startsWith("Total:")) {
                        ventaActual.append("--------------------\n"); // Añadir la división con guiones
                        ventas.Adicionar(ventaActual.toString());
                        ventaActual.setLength(0); // Reiniciar el StringBuilder para la próxima venta
                        esVentaDeFecha = false; // Reiniciar la bandera
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return ventas;
    }
    public static String buscarVentaPorFechaYHora(String filepath, String fechaHora) {
        StringBuilder ventaEncontrada = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(filepath))) {
            String linea;
            boolean esVentaDeFechaHora = false;

            while ((linea = reader.readLine()) != null) {
                if (linea.startsWith("Fecha y Hora:")) {
                    String fechaHoraVenta = linea.substring(14, 33); // Extraer la fecha y hora
                    if (fechaHoraVenta.equals(fechaHora)) {
                        esVentaDeFechaHora = true;
                        ventaEncontrada.setLength(0); // Reiniciar el StringBuilder para una nueva venta
                        ventaEncontrada.append(linea).append("\n");
                    } else {
                        esVentaDeFechaHora = false;
                    }
                } else if (esVentaDeFechaHora) {
                    ventaEncontrada.append(linea).append("\n");
                    if (linea.startsWith("Total:")) {
                        ventaEncontrada.append("--------------------\n"); // Añadir la división con guiones
                        break; // Salir del bucle una vez que se completa la venta
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return ventaEncontrada.toString();
    }
    public static String buscarDevolucionPorFechaYHora(String filepath, String fechaHora) {
        StringBuilder devolucionEncontrada = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(filepath))) {
            String linea;
            boolean esDevolucionDeFechaHora = false;

            while ((linea = reader.readLine()) != null) {
                if (linea.startsWith("Fecha y Hora:")) {
                    String fechaHoraDevolucion = linea.substring(14, 33); // Extraer la fecha y hora
                    if (fechaHoraDevolucion.equals(fechaHora)) {
                        esDevolucionDeFechaHora = true;
                        devolucionEncontrada.setLength(0); // Reiniciar el StringBuilder para una nueva devolución
                        devolucionEncontrada.append(linea).append("\n");
                    } else {
                        esDevolucionDeFechaHora = false;
                    }
                } else if (esDevolucionDeFechaHora) {
                    devolucionEncontrada.append(linea).append("\n");
                    if (linea.startsWith("Total:")) {
                        devolucionEncontrada.append("--------------------\n"); // Añadir la división con guiones
                        break; // Salir del bucle una vez que se completa la devolución
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return devolucionEncontrada.toString();
    }
    public static lista<String> buscarDevolucionesPorFecha(String filepath, String fecha) {
        lista<String> devoluciones = new lista<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filepath))) {
            String linea;
            boolean esDevolucionDeFecha = false;
            StringBuilder devolucionActual = new StringBuilder();

            while ((linea = reader.readLine()) != null) {
                if (linea.startsWith("Fecha y Hora:")) {
                    String fechaDevolucion = linea.substring(14, 24); // Extraer la fecha sin la hora
                    if (fechaDevolucion.equals(fecha)) {
                        esDevolucionDeFecha = true;
                        devolucionActual.setLength(0); // Reiniciar el StringBuilder para una nueva devolución
                        devolucionActual.append(linea).append("\n");
                    } else {
                        esDevolucionDeFecha = false;
                    }
                } else if (esDevolucionDeFecha) {
                    devolucionActual.append(linea).append("\n");
                    if (linea.startsWith("Total:")) {
                        devolucionActual.append("-------------------------------\n"); // Añadir la división con guiones
                        devoluciones.Adicionar(devolucionActual.toString());
                        devolucionActual.setLength(0); // Reiniciar el StringBuilder para la próxima devolución
                        esDevolucionDeFecha = false; // Reiniciar la bandera
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return devoluciones;
    }
    public static lista<String> extraerProductosDeVentaEnFecha(String filepath, String fechaHora) {
        lista<String> productos = new lista<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filepath))) {
            String linea;
            boolean esVentaDeFechaHora = false;

            while ((linea = reader.readLine()) != null) {
                if (linea.startsWith("Fecha y Hora:")) {
                    String fechaHoraVenta = linea.substring(14, 33); // Extraer la fecha y hora
                    if (fechaHoraVenta.equals(fechaHora)) {
                        esVentaDeFechaHora = true;
                    } else {
                        esVentaDeFechaHora = false;
                    }
                } else if (esVentaDeFechaHora && linea.startsWith("Producto:")) {
                    // Extraer el nombre del producto
                    String nombreProducto = linea.substring(10, linea.indexOf(" Codigo:"));
                    // Extraer el código del producto
                    String codigoProducto = linea.substring(linea.indexOf("Codigo:") + 8, linea.indexOf(" Cantidad:"));
                    // Extraer la cantidad vendida del producto
                    int cantidadVendida = Integer.parseInt(linea.substring(linea.indexOf("Cantidad:") + 10, linea.indexOf(" Precio:")).trim());
                    productos.Adicionar(nombreProducto + " - Código: " + codigoProducto + " - Cantidad Vendida: " + cantidadVendida);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return productos;
    }

    // Tu método existente para manejar la devolución de productos
    public static void manejarDevolucion(String ventaEncontrada) {
        // Implementación actual...
    }

    public static void escri(lista<Producto> productolista, String filepath) {
        try (BufferedWriter br = new BufferedWriter(new FileWriter(filepath))) {
            nodo<Producto> pe=productolista.getCabeza();
            while (pe!=null) {
                br.write("Nombre: "+ pe.getDato().getNombreP()+ ", Código: "+ pe.getDato().getCodigoP()+", Precio: "+ pe.getDato().getPrecioP()+", Existencia: " + pe.getDato().getExistenciaP());
                br.newLine();

                pe= pe.getSiguiente();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }


    public static void escriCliente(lista<Clientes> clienteslista, String filepath) {
        try (BufferedWriter br = new BufferedWriter(new FileWriter(filepath))) {
            nodo<Clientes> pe=clienteslista.getCabeza();
            while (pe!=null) {
                br.write("Nombre del Cliente: "+ pe.getDato().getNombreC()+ ", ID de Cliente: "+ pe.getDato().getIdCliente()+", Numero de celular: "+ pe.getDato().getNumTel()+", Puntos disponibles: "+ pe.getDato().getPuntos());
                br.newLine();
                pe= pe.getSiguiente();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static boolean buscarOperadorEnFile(String filepath, String busqueda){
        try {
            BufferedReader reader= new BufferedReader(new FileReader(filepath));
            String linea;
            while ((linea = reader.readLine()) != null) {

                String[] parts = linea.split(", ");

                String operador = parts[0];

                if (operador.equals(busqueda)){
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }


}

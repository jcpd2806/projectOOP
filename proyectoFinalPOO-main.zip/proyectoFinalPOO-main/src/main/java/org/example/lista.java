package org.example;


public class lista<T> implements listas<T>{
    private nodo<T> cabeza;
    private int tamanio;

    public lista(){
        this.cabeza = null;
        this.tamanio = 0;
    }

    public nodo<T> getCabeza() {
        return cabeza;

    }

    public int getTamanio() {
        return tamanio;
    }

    public void setTamanio(int tamanio) {
        this.tamanio = tamanio;
    }

    public void setCabeza(nodo<T> cabeza) {
        this.cabeza = cabeza;
    }

    @Override
    public void Adicionar(T x){
        nodo<T> nuevo = new nodo<>(x);
        if (cabeza == null) {
            cabeza = nuevo; // Si la lista está vacía, el nuevo nodo se convierte en la cabeza
        } else {//Agregar en la última posicion de la lista
            nodo<T> temp = cabeza;
            while (temp.getSiguiente() != null) {
                temp = temp.getSiguiente();
            }
            temp.setSiguiente(nuevo); // Enlazar el nuevo nodo al último nodo
        }
        tamanio++;
    }
    @Override
    public void insertar(T x, int indice){
        if (indice < 0 || indice > tamanio) {
            System.out.println("El índice está fuera del rango de la lista.");
            return;
        }

        nodo<T> nuevo = new nodo<>(x);
        if (indice == 0){// Insertar al principio
            nuevo.setSiguiente(cabeza);
            cabeza = nuevo;
        } else {
            // Insertar en una posición
            nodo<T> temp = cabeza;
            for (int i = 0; i < indice - 1; i++) {
                temp = temp.getSiguiente();
            }
            nuevo.setSiguiente(temp.getSiguiente()); // Enlazar el nuevo nodo al siguiente nodo del nodo anterior
            temp.setSiguiente(nuevo); // Enlazar el nodo anterior al nuevo nodo
        }
        tamanio++;
    }
    @Override
    public T obtener(int indice){
        int contador = 0;
        nodo<T> temp = cabeza;
        while (temp != null && contador < indice) {
            temp = temp.getSiguiente();
            contador++;
        }
        if (temp != null) {
            return temp.getDato();
        } else {
            return null;
        }
    }
    @Override
    public boolean isEmpty(){
        return cabeza == null;
    }
    @Override
    public void eliminar(int indice){
        int contador = 0;
        nodo<T> temp = cabeza;
        if (indice< 0 || indice >= tamanio) {
            System.out.println("El índice está fuera del rango de la lista.");
            return;
        }
        else if (indice == 0) {
            cabeza = cabeza.getSiguiente(); // se elimina el primer nodo
            tamanio--; // Decrementar el tamaño de la lista
            return;
        }else {

            while (contador < indice - 1) {
                temp = temp.getSiguiente();
                contador++;
            }
            temp.setSiguiente(temp.getSiguiente().getSiguiente());
            tamanio--;
        }
    }
    @Override
    public int longitud(){
        return tamanio;
    }
    @Override
    public int buscar(T dato) {
        nodo<T> actual = cabeza;
        int indice = 0;

        while (actual != null) {
            if (actual.getDato().equals(dato)) {//comparar mi dato de control con los nodos
                return indice;
            }
            actual = actual.getSiguiente();
            indice++;
        }
        return -1; // si no lo encuentra
    }
    @Override
    public void imprimirNodos() {
        nodo<T> temporal = cabeza;
        if (tamanio > 0){
            while (temporal != null) {
                System.out.print(temporal.getDato() + " ");
                temporal = temporal.getSiguiente();
            }
            System.out.println();
        }else{
            System.out.println("La lista está vacía");
        }
    }

    public T[] toArray() {
        int size = getTamanio();
        T[] array = (T[]) new Object[size];
        nodo<T> current = cabeza;
        int index = 0;
        while (current != null) {
            array[index++] = current.getDato();
            current = current.getSiguiente();
        }
        return array;
    }

    public int buscarString(String dato) {
        nodo<T> actual = cabeza;
        int indice = 0;

        while (actual != null) {
            if (actual.getDato().equals(dato)) {//comparar mi dato de control con los nodos
                return indice;
            }
            actual = actual.getSiguiente();
            indice++;
        }
        return -1; // si no lo encuentra
    }
}


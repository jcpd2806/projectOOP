package org.example;
import com.github.sarxos.webcam.Webcam;
import com.github.sarxos.webcam.WebcamPanel;
import com.github.sarxos.webcam.WebcamResolution;
import javax.swing.*;
import javax.swing.plaf.basic.BasicTabbedPaneUI;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.*;
import java.text.NumberFormat;
import java.util.Locale;

public class menu extends JFrame {
    private JTabbedPane ventanas;
    private JPanel perfil;
    private JPanel principal;
    private JButton cerrarSesButton;
    private JTabbedPane innerCliente;
    private JTabbedPane CodigoBP;
    private JTabbedPane innerVentas;
    private JButton botonCam;
    private JPanel panelCam;
    private JLabel fPerfil;
    private JLabel ID;
    private JTextField nombreRC;
    private JTextField celularRC;
    private JButton listoButtonRC;
    private JButton listoButtonEC;
    private JTextField idBC;
    private JButton listoButtonBC;
    private JTextField idEC;
    private JLabel IDL;
    private JTextField NombreRP;
    private JTextField ExistenciaRP;
    private JTextField PrecioRP;
    private JButton listoButtonRP;
    private JTextField CodigoAE;
    private JTextField CantidadAE;
    private JButton listoButtonAE;
    private JTextField textField6;
    private JTextField CodigoEP;
    private JPanel RegistrarCliente;
    private JPanel EliminarCliente;
    private JPanel BuscarCliente;
    private JPanel Productos;
    private JPanel RegistrarProductos;
    private JPanel ActualizarExistencia;
    private JPanel BuscarProducto;
    private JPanel EliminarProducto;
    private JPanel Inventario;
    private JPanel Ventas;
    private JPanel Venta;
    private JPanel Devoluciones;
    private JPanel VentasdelDia;
    private JPanel DevolucionesdelDia;
    private JPanel CortedeCAja;
    private JPanel Camaras;
    private JButton listoButtonBP;
    private JButton listoButtonEP;
    private JComboBox comboBoxRP;
    private JLabel reloj;
    private JTextArea InfoVenta;
    private JTextField codigoVenta;
    private JButton agregarButton;
    private JButton cobrarButton;
    private JPanel contenedorReloj;
    private JLabel LabelID;
    private JTextField cantidadVenta;
    private JComboBox comboBox1;
    private JTextPane codigoRP;
    private JTextPane paneInventario;
    private JScrollPane scrollInventario;
    private JButton actualizarInventarioButton;
    private boolean camaraActivada = false;
    private JTextField TotalPRecio;
    private JButton cancelarButton;
    private JCheckBox siCheckBox;
    private JLabel SaldoOperador;
    private JLabel totalSaldo;
    private JComboBox comboBoxDiaV;
    private JButton listoButtonVD;
    private JComboBox comboBoxMesV;
    private JComboBox comboBoxAñov;
    private JLabel ventasDelDiaLabel;
    private JPanel panelVD;
    private JScrollPane ScrollPaneVD;
    private JButton listoButtonD;
    private JLabel labelfechayhora;
    private JButton agregarProductoADevolverButton;
    private JScrollPane scrollDevolucion;
    private JTextArea textAreaDevolucion;
    private JComboBox comboBoxdiaDD;
    private JComboBox comboBoxMesDD;
    private JComboBox comboBoxAnioDD;
    private JLabel labelDevoluciones;
    private JButton listobutotonDD;
    private JScrollPane scrollPaneDevolD;
    private JTextArea ventaCortetext;
    private JTextArea devolCorteText;
    private JScrollPane devolCorteScroll;
    private JScrollPane ventasCorteScroll;
    private JButton Actualizar;
    private double totalVenta;
    private Webcam webcam;
    private  String fechaTotal = labelfechayhora.getText();
    private JButton ActualizarButtonCorte;
    private JSplitPane corteCajaSplit;
    private JLabel corteTotalVentas;
    private JLabel corteTotalDev;
    private JLabel corteTotal;
    private JButton agregarFechaButton;
    private JTextField textFieldFechaD;
    private JTextField textFieldHoraD;

    public menu(){
        setVisible(true);
        setTitle("Menu del operador");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setResizable(true);
        setMinimumSize(new Dimension(550, 500));
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        GraphicsDevice gd = ge.getDefaultScreenDevice();
        gd.setFullScreenWindow(menu.this);
        String icono = "src/main/resources/contenido/Abarrotes (1).jpg";
        ImageIcon logoOriginal = new ImageIcon(icono);
        Image imagenOriginal = logoOriginal.getImage();
        setIconImage(imagenOriginal);
        setContentPane(principal);
        Color cambio = Color.GRAY;
        Color original = ventanas.getBackground();
        ImageIcon ojo = new ImageIcon("src/main/resources/Ojo.png");
        Image ojoOr = ojo.getImage();
        Image OjoRed = ojoOr.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
        ImageIcon ojoRed = new ImageIcon(OjoRed);
        ImageIcon ojoCerr = new ImageIcon("src/main/resources/ojoCerrado.png");
        Image ojoCerra = ojoCerr.getImage();
        Image OjoCerrado = ojoCerra.getScaledInstance(50,50,Image.SCALE_SMOOTH);
        ImageIcon OCerr = new ImageIcon(OjoCerrado);
        botonCam.setIcon(ojoRed);
        ImageIcon perfil = new ImageIcon("src/main/resources/contenido/Icono perfil.png");
        Image perfilRed = perfil.getImage().getScaledInstance(300,300,Image.SCALE_SMOOTH);
        ImageIcon FPerfil = new ImageIcon(perfilRed);
        fPerfil.setIcon((FPerfil));
        celularRC.setDocument(new NoNada());
        //nombreRC.setDocument(new onlyLetras());
        idEC.setDocument(new onlyNumbs());
        idBC.setDocument(new onlyNumbs());
        //NombreRP.setDocument(new onlyLetras());
        ExistenciaRP.setDocument(new onlyNumbs());
        //PrecioRP.setDocument(new onlyNumbs());
        //CodigoAE.setDocument(new onlyNumbs());
        //CantidadAE.setDocument(new onlyNumbs());
        //textField6.setDocument(new onlyNumbs());
        //CodigoEP.setDocument(new onlyNumbs());

        iniciarReloj();
        contenedorReloj.setSize(100,50);
        verificarWebcam();
        lista<ProductoVenta> prod = Tiendita.leerProductosDesdeArchivo();
        codigoRP.setEditable(false);
        InfoVenta.setEditable(false);
        //codigoVenta.setEditable(false);
        scrollInventario.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        paneInventario.setEditable(false);
        scrollPaneDevolD.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        ventasCorteScroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        devolCorteScroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        corteCajaSplit.setDividerLocation(850);
        ventaCortetext.setEditable(false);
        devolCorteText.setEditable(false);
        LabelID.setText(Tiendite.getIdUsus());

        /*manejoArchivo.ExtreaerProductos(Tiendita.getProductosFile());
        manejoArchivo.ExtreaerClientes(Tiendita.getClientesFile());*/


        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String fechaHoy = today.format(formatter);
        if (!manejoArchivo.buscarVentasPorFecha(Tiendita.getVentasFile(), fechaHoy).isEmpty()){
            lista<String> ventas = manejoArchivo.buscarVentasPorFecha(Tiendita.getVentasFile(), fechaHoy);
            lista<String>  devo= manejoArchivo.buscarDevolucionesPorFecha(Tiendita.getDevolFile(),fechaHoy);
            double totalVentas = calcularTotal(ventas);
            double totalDevoluciones = calcularTotal(devo);
            double jhsa= totalVentas - totalDevoluciones + 1000;
            Tiendita.setSaldo(jhsa);
            totalSaldo.setText(String.valueOf(Tiendita.getSaldo()));
        }




        if (manejoArchivo.Novacio(Tiendita.getProductosFile())){
            manejoArchivo.ExtreaerProductos(Tiendita.getProductosFile());
            nodo<Producto> c=Tiendita.getProductolista().getCabeza();
            while (c!=null){

                String id= c.getDato().getCodigoP();
                if (EsNumeroEntero(id.substring(1))){
                    Tiendita.setContadorCodigo(Integer.parseInt(id.substring(1)));
                }else if (EsNumeroEntero(id.substring(2))){
                    Tiendita.setContadorCodigo(Integer.parseInt(id.substring(2)));
                }
                c=c.getSiguiente();
            }
        }
        if (manejoArchivo.Novacio(Tiendita.getClientesFile())){
            manejoArchivo.ExtreaerClientes(Tiendita.getClientesFile());
            nodo<Clientes> c=Tiendita.getClienteslista().getCabeza();
            while (c!=null){

                String id= String.valueOf(c.getDato().getIdCliente());
                Tiendita.setContadorCliente(c.getDato().getIdCliente());
                c=c.getSiguiente();
            }

            /*nodo<Clientes> c=Tiendita.getClienteslista().getCabeza();
            while (c!=null){
                Tiendita.setContadorCliente(c.getDato().getIdCliente());
                c=c.getSiguiente();
            }*/
        }

        paneInventario.setText(Tiendita.showProductos(Tiendita.getProductolista()));
        highlightText(paneInventario, "Productos sin stock:", Color.RED);
        comboBox1.setModel(new DefaultComboBoxModel(prod.toArray()));
        totalSaldo.setText(String.valueOf(Tiendita.getSaldo()));
        ScrollPaneVD.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        textAreaDevolucion.setEditable(false);

        ventanas.setUI(new BasicTabbedPaneUI() {

            @Override
            protected int calculateTabHeight(int tabPlacement, int tabIndex, int fontHeight) {
                return super.calculateTabHeight(tabPlacement, tabIndex, fontHeight) + 20; // Aumenta 20 píxeles
            }

            @Override
            protected int calculateTabWidth(int tabPlacement, int tabIndex, FontMetrics metrics) {
                return super.calculateTabWidth(tabPlacement, tabIndex, metrics) + 40; // Aumenta 40 píxeles
            }
            private Color selectedTabColor = Color.GRAY;
            protected void paintTabBackground(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected) {
                if (isSelected) {
                    g.setColor(selectedTabColor); // Usa el color de resaltado personalizado
                } else {
                    Color backgroundColor = ventanas.getBackground();
                    if (backgroundColor == null) {
                        backgroundColor = UIManager.getColor("Panel.background"); // Color predeterminado para paneles
                    }
                    g.setColor(backgroundColor);
                }
                g.fillRect(x, y, w, h);
            }

        });
        botonCam.addActionListener(new ActionListener() {
            private WebcamPanel panel;
            @Override
            public void actionPerformed(ActionEvent e) {
                if (camaraActivada) {
                    webcam.close(); // Cerrar la cámara
                    panelCam.removeAll(); // Quitar todos los componentes del panel de la cámara
                    panelCam.revalidate(); // Actualizar el layout
                    panelCam.repaint(); // Repintar el panel
                    botonCam.setIcon(ojoRed);
                } else {
                    webcam.open(); // Abrir la cámara
                    panel = new WebcamPanel(webcam); // Crear una nueva instancia de WebcamPanel
                    panel.setFPSDisplayed(true);
                    panel.setDisplayDebugInfo(true);
                    panel.setImageSizeDisplayed(true);
                    panel.setMirrored(true);
                    panelCam.add(panel, BorderLayout.CENTER); // Agregar el panel de la cámara
                    panelCam.revalidate(); // Actualizar el layout
                    panelCam.repaint(); // Repintar el panel
                    botonCam.setIcon(OCerr);
                }
                camaraActivada = !camaraActivada; // Cambiar el estado de la cámara
            }
        });
        innerCliente.setUI(new BasicTabbedPaneUI(){

            @Override
            protected int calculateTabHeight(int tabPlacement, int tabIndex, int fontHeight) {
                return super.calculateTabHeight(tabPlacement, tabIndex, fontHeight) + 20; // Aumenta 20 píxeles
            }

            @Override
            protected int calculateTabWidth(int tabPlacement, int tabIndex, FontMetrics metrics) {
                return super.calculateTabWidth(tabPlacement, tabIndex, metrics) + 40; // Aumenta 40 píxeles
            }
            private Color selectedTabColor = Color.GRAY;
            protected void paintTabBackground(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected) {
                if (isSelected) {
                    g.setColor(selectedTabColor); // Usa el color de resaltado personalizado
                } else {
                    Color backgroundColor = ventanas.getBackground();
                    if (backgroundColor == null) {
                        backgroundColor = UIManager.getColor("Panel.background"); // Color predeterminado para paneles
                    }
                    g.setColor(backgroundColor);
                }
                g.fillRect(x, y, w, h);
            }

        });
        CodigoBP.setUI(new BasicTabbedPaneUI()
        {

            @Override
            protected int calculateTabHeight(int tabPlacement, int tabIndex, int fontHeight) {
                return super.calculateTabHeight(tabPlacement, tabIndex, fontHeight) + 20; // Aumenta 20 píxeles
            }

            @Override
            protected int calculateTabWidth(int tabPlacement, int tabIndex, FontMetrics metrics) {
                return super.calculateTabWidth(tabPlacement, tabIndex, metrics) + 40; // Aumenta 40 píxeles
            }
            private Color selectedTabColor = Color.GRAY;
            protected void paintTabBackground(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected) {
                if (isSelected) {
                    g.setColor(selectedTabColor); // Usa el color de resaltado personalizado
                } else {
                    Color backgroundColor = ventanas.getBackground();
                    if (backgroundColor == null) {
                        backgroundColor = UIManager.getColor("Panel.background"); // Color predeterminado para paneles
                    }
                    g.setColor(backgroundColor);
                }
                g.fillRect(x, y, w, h);
            }

        });
        innerVentas.setUI(new BasicTabbedPaneUI(){
        @Override
        protected int calculateTabHeight(int tabPlacement, int tabIndex, int fontHeight) {
            return super.calculateTabHeight(tabPlacement, tabIndex, fontHeight) + 20; // Aumenta 20 píxeles
        }

        @Override
        protected int calculateTabWidth(int tabPlacement, int tabIndex, FontMetrics metrics) {
            return super.calculateTabWidth(tabPlacement, tabIndex, metrics) + 40; // Aumenta 40 píxeles
        }
        private Color selectedTabColor = Color.GRAY;
        protected void paintTabBackground(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected) {
            if (isSelected) {
                g.setColor(selectedTabColor); // Usa el color de resaltado personalizado
            } else {
                Color backgroundColor = ventanas.getBackground();
                if (backgroundColor == null) {
                    backgroundColor = UIManager.getColor("Panel.background"); // Color predeterminado para paneles
                }
                g.setColor(backgroundColor);
            }
            g.fillRect(x, y, w, h);
        }
        });
        cerrarSesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane optionPane = new JOptionPane("¿Desea cerrar sesión?",
                        JOptionPane.INFORMATION_MESSAGE,
                        JOptionPane.YES_NO_OPTION);
                JDialog dialog = optionPane.createDialog(menu.this, "Cerrar sesión");
                dialog.setAlwaysOnTop(true); // Asegurarse de que el JDialog esté siempre en la parte superior
                dialog.setModal(true); // Hacer que el JDialog sea modal
                dialog.setVisible(true); // Mostrar el JDialog
                int selecc = (int) optionPane.getValue();
                if(selecc == JOptionPane.YES_OPTION){
                    new Tiendite();
                    dispose();
                }
            }
        });

        listoButtonRC.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (!nombreRC.getText().isBlank() && !celularRC.getText().isBlank()) {
                    String nombreRCliente = nombreRC.getText().toLowerCase();
                    String celularCliente = celularRC.getText().replaceAll("\\s", "");
                    int id = Tiendita.crearCliente(nombreRCliente, celularCliente);
                    JOptionPane cliCre = new JOptionPane("El ID del cliente es: " + id, JOptionPane.INFORMATION_MESSAGE);
                    JDialog CreadoCli = cliCre.createDialog(menu.this, "Usuario registrado con éxito");
                    String message = "Nombre del Cliente: "+ nombreRCliente+ ", ID de Cliente: "+id+", Numero de celular: "+celularCliente+ ", Puntos disponibles: 0.0";
                    manejoArchivo.EscribirArchivo(Tiendita.getClientesFile(),message);
                    CreadoCli.setAlwaysOnTop(true);
                    CreadoCli.setModal(true);
                    CreadoCli.setVisible(true);
                    nombreRC.setText("");
                    celularRC.setText("");
                } else {
                    JOptionPane errorRC = new JOptionPane("Llene los espacios.", JOptionPane.ERROR_MESSAGE);
                    JDialog ErrorRC = errorRC.createDialog(menu.this, "Error al registrar cliente");
                    ErrorRC.setVisible(true);
                    ErrorRC.setAlwaysOnTop(true);
                    nombreRC.setText("");
                    celularRC.setText("");
                }
            }
        });

        listoButtonEC.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!idEC.getText().isBlank()){
                    try {
                        int Idc = Integer.parseInt(idEC.getText());
                        int confirm = Tiendita.DarBajaCliente(Idc);
                        if(confirm != -1){
                        JOptionPane successPane = new JOptionPane("El usuario " + Idc + " se eliminó con éxito.", JOptionPane.INFORMATION_MESSAGE);
                        JDialog successDialog = successPane.createDialog(menu.this, "Cliente eliminado");
                        manejoArchivo.escriCliente(Tiendita.getClienteslista(),Tiendita.getClientesFile());
                        successDialog.setAlwaysOnTop(true);
                        successDialog.setModal(true);
                        successDialog.setVisible(true);
                        idEC.setText("");
                        }else{
                            JOptionPane emptyFieldsPane = new JOptionPane("El usuario ingresado no existe.", JOptionPane.ERROR_MESSAGE);
                            JDialog emptyFieldsDialog = emptyFieldsPane.createDialog(menu.this, "Error al eliminar cliente");
                            emptyFieldsDialog.setAlwaysOnTop(true);
                            emptyFieldsDialog.setModal(true);
                            emptyFieldsDialog.setVisible(true);
                            idEC.setText("");
                        }


                    } catch (NumberFormatException x) {
                        // Crear el JOptionPane para el mensaje de error de formato de número
                        JOptionPane errorPane = new JOptionPane("ID inválido. Por favor, ingresa un número válido.", JOptionPane.ERROR_MESSAGE);
                        JDialog errorDialog = errorPane.createDialog(menu.this, "Error");
                        errorDialog.setAlwaysOnTop(true);
                        errorDialog.setModal(true);
                        errorDialog.setVisible(true);
                        idEC.setText("");
                    }
                } else {
                    // Crear el JOptionPane para el mensaje de campos vacíos
                    JOptionPane emptyFieldsPane = new JOptionPane("Llena los espacios vacíos.", JOptionPane.ERROR_MESSAGE);
                    JDialog emptyFieldsDialog = emptyFieldsPane.createDialog(menu.this, "Error al eliminar cliente");
                    emptyFieldsDialog.setAlwaysOnTop(true);
                    emptyFieldsDialog.setModal(true);
                    emptyFieldsDialog.setVisible(true);
                    idEC.setText("");
                }
            }
        });

        listoButtonBC.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!idBC.getText().isBlank()){
                    String IdBC = idBC.getText();
                    if(Tiendita.BuscarClientes(Integer.parseInt(IdBC)) != null){
                        Clientes cliente = Tiendita.BuscarClientes(Integer.parseInt(IdBC));
                        assert cliente != null;
                        JOptionPane successPane = new JOptionPane("Cliente encontrado \n" + "ID: " + cliente.getIdCliente() + "\n" + "Nombre: " + cliente.getNombreC() + "\n"+ "Número de teléfono: " + cliente.getNumTel() + "\n" + "Puntos: " + cliente.getPuntos() + "\n", JOptionPane.INFORMATION_MESSAGE);
                        JDialog successDialog = successPane.createDialog(menu.this, "Cliente encontado");
                        successDialog.setAlwaysOnTop(true);
                        successDialog.setModal(true);
                        successDialog.setVisible(true);
                        idBC.setText("");
                    }else{
                        JOptionPane FailPane = new JOptionPane("El cliente no se encontró.", JOptionPane.ERROR_MESSAGE);
                        //JOptionPane.showMessageDialog(menu.this,"El cliente no se encontró");
                         JDialog FailDialog = FailPane.createDialog(menu.this, "Error al buscar cliente.");
                        FailDialog.setAlwaysOnTop(true);
                        FailDialog.setModal(true);
                        FailDialog.setVisible(true);
                        idBC.setText("");
                    }

                } else {
                    JOptionPane errorBC = new JOptionPane("Llena los espacios vacios.",JOptionPane.ERROR_MESSAGE);
                    JDialog errorBCDialog = errorBC.createDialog(menu.this, "Error al buscar cliente");
                    errorBCDialog.setAlwaysOnTop(true);
                    errorBCDialog.setModal(true);
                    errorBCDialog.setVisible(true);
                    idBC.setText("");
                }
            }
        });


        listoButtonRP.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!NombreRP.getText().isBlank() && !ExistenciaRP.getText().isBlank() && !PrecioRP.getText().isBlank() && !Objects.equals(comboBoxRP.getSelectedItem().toString().toLowerCase(), "")){
                    if (!EsNumero(NombreRP.getText())&&EsNumero(PrecioRP.getText())&&EsNumeroEntero(ExistenciaRP.getText())){
                        String nombre = NombreRP.getText();
                        String pre = PrecioRP.getText();
                        double precio = Double.parseDouble(pre);
                        String exis = ExistenciaRP.getText();
                        int existencia = Integer.parseInt(exis);
                        String tipo = (String) comboBoxRP.getSelectedItem();
                        String cod= Tiendita.CrearProducto(nombre,precio,existencia,tipo);

                        String message = "Nombre: "+nombre +", Código: " + cod+ ", Precio: "+ precio+ ", Existencia: "+ existencia;
                        manejoArchivo.EscribirArchivo(Tiendita.getProductosFile(),message);
//                    JOptionPane.showMessageDialog(null,"1");
                        ProductoVenta pv = new ProductoVenta(nombre,cod,existencia,precio);
                        prod.Adicionar(pv);
                        comboBox1.setModel(new DefaultComboBoxModel(prod.toArray()));
                        NombreRP.setText("");
                        PrecioRP.setText("");
                        ExistenciaRP.setText("");
                        codigoRP.setText(cod);
                    }else {
                        JOptionPane.showMessageDialog(menu.this,"Favor de llenar los espacios con datos correctos.","Error de formato",JOptionPane.ERROR_MESSAGE);
                        NombreRP.setText("");
                        PrecioRP.setText("");
                        ExistenciaRP.setText("");
                    }

                } else {
                    JOptionPane.showMessageDialog(menu.this,"Llena los espacios vacios","Error por espacio en blanco", JOptionPane.ERROR_MESSAGE);
                    NombreRP.setText("");
                    PrecioRP.setText("");
                    ExistenciaRP.setText("");
                }
            }
        });

        listoButtonAE.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!CodigoAE.getText().isBlank() && !CantidadAE.getText().isBlank()){

                    if (!EsNumero(CodigoAE.getText())&&EsNumeroEntero(CantidadAE.getText())){
                        String cod = CodigoAE.getText();
                        String cant = CantidadAE.getText();
                        int cantidad = Integer.parseInt(cant);
                        Producto p = Tiendita.BuscarProducto(cod);
                        if (p != null) {
                            int ex = p.getExistenciaP() + cantidad;
                            p.setExistenciaP(ex);
                            manejoArchivo.escri(Tiendita.getProductolista(),Tiendita.getProductosFile());
                            JOptionPane.showMessageDialog(menu.this,"Producto actualizado.\nNombre: "+ p.getNombreP()+"\nCantidad en existencia: "+(p.getExistenciaP()));
                            CodigoAE.setText("");
                            CantidadAE.setText("");
                        } else {
                            JOptionPane.showMessageDialog(menu.this,"El producto no existe. \nFavor de registrar el producto si se encuentra en existencia.","Producto inexistente", JOptionPane.INFORMATION_MESSAGE);
                            CodigoAE.setText("");
                            CantidadAE.setText("");
                        }
                    }else {
                        JOptionPane.showMessageDialog(menu.this,"Favor de llenar los espacios con datos correctos.","Error de formato",JOptionPane.ERROR_MESSAGE);
                        CodigoAE.setText("");
                        CantidadAE.setText("");
                    }
                } else {
                    JOptionPane.showMessageDialog(menu.this,"Llena los espacios vacios","Error por espacio en blanco", JOptionPane.ERROR_MESSAGE);
                    CodigoAE.setText("");
                    CantidadAE.setText("");
                }
            }
        });

        listoButtonBP.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!textField6.getText().isBlank()){

                    if (!EsNumero(textField6.getText())){
                        String cd = textField6.getText();
                        Producto po = Tiendita.BuscarProducto(cd);
                        if (po != null){
                            JOptionPane.showMessageDialog(menu.this,"El producto "+po.getNombreP()+" ("+ po.getCodigoP() +")"+ " se encuentra disponible: " + po.getExistenciaP());
                            textField6.setText("");
                        } else {
                            JOptionPane.showMessageDialog(menu.this,"El producto no existe. \nFavor de registrar el producto si se encuentra en existencia.","Producto inexistente", JOptionPane.INFORMATION_MESSAGE);
                            textField6.setText("");
                        }
                    }else {
                        JOptionPane.showMessageDialog(menu.this,"Favor de llenar los espacios con datos correctos.","Error de formato",JOptionPane.ERROR_MESSAGE);
                        textField6.setText("");
                    }
                } else {
                    JOptionPane.showMessageDialog(menu.this,"Llena los espacios vacios","Error por espacio en blanco", JOptionPane.ERROR_MESSAGE);
                    textField6.setText("");
                }
            }
        });

        listoButtonEP.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!CodigoEP.getText().isBlank()){

                    if (!EsNumero(CodigoEP.getText())){
                        String cosita = CodigoEP.getText();
                        Producto p = Tiendita.BuscarProducto(cosita);
                        if (p != null) {
                            Tiendita.DarBajaProducto(cosita);
                            JOptionPane.showMessageDialog(menu.this,"Producto "+ p.getNombreP() +" ("+ cosita +")"+ " eliminado con éxito." );
                            manejoArchivo.escri(Tiendita.getProductolista(),"Productos.txt");
                            CodigoEP.setText("");
                        } else {
                            JOptionPane.showMessageDialog(menu.this,"El producto ingresado no existe.","Producto inexistente", JOptionPane.INFORMATION_MESSAGE);
                            CodigoEP.setText("");
                        }
                    }else {
                        JOptionPane.showMessageDialog(menu.this,"Favor de llenar los espacios con datos correctos.","Error de formato",JOptionPane.ERROR_MESSAGE);
                        CodigoEP.setText("");
                    }


                } else {
                    JOptionPane.showMessageDialog(menu.this,"Llena los espacios vacios","Error por espacio en blanco", JOptionPane.ERROR_MESSAGE);
                    CodigoEP.setText("");
                }
            }
        });



        cobrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!InfoVenta.getText().isBlank()) {
                    JOptionPane optionPane = new JOptionPane(
                            "¿Desea confirmar la compra?",
                            JOptionPane.QUESTION_MESSAGE,
                            JOptionPane.YES_NO_OPTION
                    );

                    JDialog dialog = optionPane.createDialog(menu.this, "Confirmar compra");
                    dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
                    dialog.setVisible(true);

                    Object response = optionPane.getValue();

                    if (response != null && (int) response == JOptionPane.YES_OPTION) {
                        String texto = InfoVenta.getText();
                        String[] lineas = texto.split("\n");
                        boolean primeraLinea = true;

                        for (String linea : lineas) {
                            if (primeraLinea) {
                                primeraLinea = false;
                                continue;
                            }
                            Pattern patternCodigo = Pattern.compile("Código: (\\w+)");
                            Matcher matcherCodigo = patternCodigo.matcher(linea);
                            String codigo = "";
                            if (matcherCodigo.find()) {
                                codigo = matcherCodigo.group(1).trim();
                            }

                            Pattern patternCantidad = Pattern.compile("Cantidad: (\\d+)");
                            Matcher matcherCantidad = patternCantidad.matcher(linea);
                            int cantidad = 0;
                            if (matcherCantidad.find()) {
                                cantidad = Integer.parseInt(matcherCantidad.group(1));
                            }

                            Producto p = Tiendita.BuscarProducto(codigo);
                            if (p != null) {
                                int existenciaActual = p.getExistenciaP();
                                if (cantidad <= existenciaActual) {
                                    p.setExistenciaP(existenciaActual - cantidad);
                                } else {
                                    System.out.println("Error: La cantidad a restar es mayor que la existencia actual del producto " + codigo);
                                    return;
                                }
                            } else {
                                System.out.println("Error: Producto no encontrado con el código " + codigo);
                            }
                        }

                        final String[] clienteInfo = {null};

                        if (siCheckBox.isSelected()) {
                            double total = Double.parseDouble(TotalPRecio.getText());
                            JDialog dialogo = new JDialog();
                            dialogo.setTitle("Información del cliente");
                            dialogo.setLayout(new BorderLayout());

                            JLabel idClienteLabel = new JLabel("ID Cliente:");
                            JTextField idClienteField = new JTextField();
                            idClienteField.setDocument(new onlyNumbs());
                            dialogo.add(idClienteLabel, BorderLayout.WEST);
                            dialogo.add(idClienteField, BorderLayout.CENTER);
                            dialogo.setSize(300, 150);
                            JButton button = new JButton("Listo");
                            dialogo.add(button, BorderLayout.SOUTH);
                            dialogo.setResizable(false);
                            dialogo.setAlwaysOnTop(true);
                            dialogo.setLocationRelativeTo(null);

                            button.addActionListener(new ActionListener() {
                                @Override
                                public void actionPerformed(ActionEvent e) {
                                    if (idClienteField.getText().isEmpty()) {
                                        JOptionPane.showMessageDialog(dialogo, "Favor de llenar el espacio.", "ERROR", JOptionPane.ERROR_MESSAGE);
                                    } else {
                                        String idCliente = idClienteField.getText();
                                        Clientes cliente = Tiendita.BuscarClientes(Integer.parseInt(idCliente));

                                        if (cliente != null) {
                                            dialogo.dispose();
                                            double puntos = totalVenta * 0.03;

                                            if (cliente.getPuntos() > 0) {
                                                int usarPuntos = JOptionPane.showConfirmDialog(dialogo,
                                                        "Cliente: " + cliente.getNombreC() + "\nPuntos disponibles: " + cliente.getPuntos() + "\nTotal de la compra: " + totalVenta + " \n¿Desea realizar la compra con puntos?",
                                                        "Usar puntos",
                                                        JOptionPane.YES_NO_OPTION);

                                                if (usarPuntos == JOptionPane.YES_OPTION) {
                                                    if (cliente.getPuntos() >= totalVenta) {
                                                        totalVenta = 0;
                                                        cliente.setPuntos(cliente.getPuntos() - (int) total);
                                                    } else {
                                                        totalVenta -= cliente.getPuntos();
                                                        cliente.setPuntos(0);
                                                    }
                                                    JOptionPane.showMessageDialog(dialogo, "Total después de usar puntos: " + totalVenta + "\nPuntos restantes: " + cliente.getPuntos());

                                                    realizarCobro();

                                                    clienteInfo[0] = cliente.getNombreC() + " (ID: " + cliente.getIdCliente() + ")";
                                                    finalizarVenta(InfoVenta.getText(), clienteInfo[0]);

                                                } else if (usarPuntos == JOptionPane.NO_OPTION) {
                                                    cliente.setPuntos(cliente.getPuntos() + puntos);
                                                    realizarCobro();
                                                    JOptionPane.showMessageDialog(dialogo, "Puntos generados por la compra: " + puntos);

                                                    clienteInfo[0] = cliente.getNombreC() + " (ID: " + cliente.getIdCliente() + ")";
                                                    finalizarVenta(InfoVenta.getText(), clienteInfo[0]);
                                                }
                                            } else {
                                                cliente.setPuntos(cliente.getPuntos() + puntos);
                                                clienteInfo[0] = cliente.getNombreC() + " (ID: " + cliente.getIdCliente() + ")";
                                                JOptionPane.showMessageDialog(dialogo, "Puntos en cero.\nTotal sin utilizar puntos: " + totalVenta + "\nPuntos generados por la compra: " + cliente.getPuntos());

                                                realizarCobro();

                                                finalizarVenta(InfoVenta.getText(), clienteInfo[0]);
                                            }

                                        } else {
                                            int opcion = JOptionPane.showOptionDialog(dialogo,
                                                    "Cliente no encontrado. ¿Desea ingresar otro ID o continuar como no cliente?",
                                                    "Cliente no encontrado",
                                                    JOptionPane.YES_NO_OPTION,
                                                    JOptionPane.QUESTION_MESSAGE,
                                                    null,
                                                    new String[]{"Ingresar otro ID", "Continuar como no cliente"},
                                                    "Ingresar otro ID");

                                            if (opcion == JOptionPane.YES_OPTION) {
                                                idClienteField.setText("");
                                            } else if (opcion == JOptionPane.NO_OPTION) {
                                                realizarCobro();
                                                finalizarVenta(InfoVenta.getText(), null);
                                            } else {
                                                dialogo.dispose();
                                            }
                                        }
                                    }
                                }
                            });

                            dialogo.setModal(true);
                            dialogo.setAlwaysOnTop(true);
                            dialogo.setVisible(true);

                        } else {
                            realizarCobro();
                            finalizarVenta(InfoVenta.getText(), null);
                        }
                    } else {
                        InfoVenta.setText("");
                        TotalPRecio.setText("");
                        totalVenta = 0;
                    }
                } else {
                    JOptionPane noProd = new JOptionPane("No se ingresó ningún producto", JOptionPane.ERROR_MESSAGE);
                    JDialog errorVenta = noProd.createDialog(menu.this, "Error al realizar la venta");
                    errorVenta.setAlwaysOnTop(true);
                    errorVenta.setModal(true);
                    errorVenta.setVisible(true);
                }
            }

            private void realizarCobro() {
                while (true) {
                    String cantidadStr = JOptionPane.showInputDialog(menu.this, "Ingrese la cantidad recibida $ ", "Solicitar Dinero", JOptionPane.QUESTION_MESSAGE);

                    if (cantidadStr != null && !cantidadStr.isEmpty()) {
                        try {
                            double cantidad = Double.parseDouble(cantidadStr);

                            if (cantidad >= totalVenta) {
                                double totalD = cantidad - totalVenta;
                                JOptionPane.showMessageDialog(menu.this, "Cantidad válida, el total a devolver es: " + totalD, "Cantidad Ingresada", JOptionPane.INFORMATION_MESSAGE);
                                break;
                            } else {
                                JOptionPane.showMessageDialog(menu.this, "La cantidad ingresada es menor a $" + totalVenta + ". Por favor, ingrese una cantidad válida.", "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        } catch (NumberFormatException f) {
                            JOptionPane.showMessageDialog(menu.this, "Entrada no válida. Por favor, ingrese un número válido.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } else {
                        JOptionPane.showMessageDialog(menu.this, "No se ingresó ninguna cantidad.", "Aviso", JOptionPane.WARNING_MESSAGE);
                    }
                }
            }
        });


                listoButtonVD.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String fecha = comboBoxAñov.getSelectedItem() + "-" + comboBoxMesV.getSelectedItem() + "-" + comboBoxDiaV.getSelectedItem();
                if (!fecha.isBlank()) {
                    String filepath = Tiendita.getVentasFile(); // Actualiza esta ruta según tu archivo
                    lista<String> ventas = manejoArchivo.buscarVentasPorFecha(filepath, fecha);
                    if (!ventas.isEmpty()) {
                        StringBuilder ventasText = new StringBuilder("<html>");
                        for (int i = 0; i < ventas.getTamanio(); i++) {
                            ventasText.append(ventas.obtener(i).replace("\n", "<br>")).append("<br><br>");
                        }
                        ventasText.append("</html>");
                        ventasDelDiaLabel.setText(ventasText.toString());

                        // Agregar el texto actualizado al JLabel dentro del JScrollPane
                        JScrollPane scrollPane = (JScrollPane) ventasDelDiaLabel.getParent().getParent(); // Obtener el JScrollPane que contiene al JLabel
                        scrollPane.setViewportView(ventasDelDiaLabel); // Actualizar el contenido del JScrollPane
                    } else {
                        JOptionPane errorventasDelDiaLabel = new JOptionPane("No hay registros de la fecha ingresada, favor de introducir una fecha válida", JOptionPane.INFORMATION_MESSAGE);
                        JDialog error = errorventasDelDiaLabel.createDialog(menu.this, "Error al buscar registros");
                        error.setAlwaysOnTop(true);
                        error.setModal(true);
                        error.setVisible(true);
                        ventasDelDiaLabel.setText("");
                    }
                } else {
                    JOptionPane errorventasDelDiaLabel = new JOptionPane("No hay registros de la fecha ingresada, favor de introducir una fecha válida", JOptionPane.INFORMATION_MESSAGE);
                    JDialog error = errorventasDelDiaLabel.createDialog(menu.this, "Error al buscar registros");
                    error.setAlwaysOnTop(true);
                    error.setModal(true);
                    error.setVisible(true);
                    ventasDelDiaLabel.setText("");
                }
            }
        });
        listobutotonDD.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String fecha = comboBoxAnioDD.getSelectedItem() + "-" + comboBoxMesDD.getSelectedItem() + "-" + comboBoxdiaDD.getSelectedItem();
                if (!fecha.isBlank()) {
                    String filepath = Tiendita.getDevolFile(); // Ruta al archivo de devoluciones
                    lista<String> devoluciones = manejoArchivo.buscarDevolucionesPorFecha(filepath, fecha); // Método para buscar devoluciones por fecha
                    if (!devoluciones.isEmpty()) {
                        StringBuilder devolucionesText = new StringBuilder("<html>");
                        for (int i = 0; i < devoluciones.getTamanio(); i++) {
                            devolucionesText.append(devoluciones.obtener(i).replace("\n", "<br>")).append("<br><br>");
                        }
                        devolucionesText.append("</html>");
                        labelDevoluciones.setText(devolucionesText.toString());

                        // Agregar el texto actualizado al JLabel dentro del JScrollPane
                        JScrollPane scrollPane = (JScrollPane) scrollPaneDevolD.getParent().getParent(); // Obtener el JScrollPane que contiene al JLabel
                        scrollPane.setViewportView(labelDevoluciones); // Actualizar el contenido del JScrollPane
                    } else {
                        JOptionPane errorventasDelDiaLabel = new JOptionPane("No hay devoluciones registradas para la fecha ingresada, favor de introducir una fecha válida", JOptionPane.INFORMATION_MESSAGE);
                        JDialog error = errorventasDelDiaLabel.createDialog(menu.this, "Error al buscar registros");
                        error.setAlwaysOnTop(true);
                        error.setModal(true);
                        error.setVisible(true);
                        labelDevoluciones.setText("");
                    }
                } else {
                    JOptionPane errorventasDelDiaLabel = new JOptionPane("No hay devoluciones registradas para la fecha ingresada, favor de introducir una fecha válida", JOptionPane.INFORMATION_MESSAGE);
                    JDialog error = errorventasDelDiaLabel.createDialog(menu.this, "Error al buscar registros");
                    error.setAlwaysOnTop(true);
                    error.setModal(true);
                    error.setVisible(true);
                    labelDevoluciones.setText("");
                }
            }
        }); //lklklklk
        agregarProductoADevolverButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (!labelfechayhora.getText().equals("AAAA-MM-DD HH:MM:SS")) {
                lista<String> productos = manejoArchivo.extraerProductosDeVentaEnFecha(Tiendita.getVentasFile(), labelfechayhora.getText());

                // Crear un JComboBox con los productos de las ventas
                JComboBox<String> comboBoxProductos = new JComboBox<>();
                for (int i = 0; i < productos.getTamanio(); i++) {
                    comboBoxProductos.addItem(productos.obtener(i));
                }

                // Mostrar el JOptionPane con el JComboBox para seleccionar el producto
                int opcionProducto = JOptionPane.showOptionDialog(menu.this, comboBoxProductos, "Seleccione el producto a devolver",
                        JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
                if (opcionProducto == JOptionPane.OK_OPTION) {
                    String productoSeleccionado = (String) comboBoxProductos.getSelectedItem();

                    // Obtener la cantidad vendida del producto seleccionado
                    int cantidadVendida = Integer.parseInt(productoSeleccionado.substring(productoSeleccionado.lastIndexOf(":") + 2).trim());

                    // Verificar si el producto ya ha sido agregado anteriormente
                    String[] lineas = textAreaDevolucion.getText().split("\n");
                    boolean productoYaAgregado = false;
                    for (String linea : lineas) {
                        if (linea.contains(productoSeleccionado)) {
                            productoYaAgregado = true;
                            break;
                        }
                    }

                    // Pedir al usuario que ingrese la cantidad a devolver
                    if (!productoYaAgregado) {
                        String cantidadIngresada = JOptionPane.showInputDialog(menu.this, "Ingrese la cantidad a devolver (Máximo: " + cantidadVendida + ")",
                                "Cantidad a Devolver", JOptionPane.QUESTION_MESSAGE);

                        if (cantidadIngresada != null) {
                            int cantidadADevolver = Integer.parseInt(cantidadIngresada);

                            if (cantidadADevolver > 0 && cantidadADevolver <= cantidadVendida) {
                                String datosProducto = "Producto: " + productoSeleccionado + " - Cantidad a Devolver: " + cantidadADevolver;
                                textAreaDevolucion.setText(textAreaDevolucion.getText() + "\n" + datosProducto);
                            } else {
                                JOptionPane.showMessageDialog(menu.this, "La cantidad ingresada no es válida", "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        }
                    } else {
                        JOptionPane.showMessageDialog(menu.this, "El producto ya ha sido agregado anteriormente", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane error = new JOptionPane("Favor de seleccionar una fecha", JOptionPane.ERROR_MESSAGE);
                JDialog mensajeError = error.createDialog(menu.this, "Error al agregar producto");
                mensajeError.setVisible(true);
                mensajeError.setModal(true);
                mensajeError.setAlwaysOnTop(true);
            }
        }
            });
        listoButtonD.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String textoDevolucion = textAreaDevolucion.getText();
                if(!textoDevolucion.isEmpty()) {
                    // Separar el texto en líneas
                    String[] lineas = textoDevolucion.split("\n");

                    // Variables para almacenar el precio total de la devolución
                    double precioTotalDevolucion = 0.0;

                    // Expresión regular para buscar el código, la cantidad vendida y la cantidad a devolver en cada línea
                    String regex = "Código: (\\w+) - Cantidad Vendida: (\\d+) - Cantidad a Devolver: (\\d+)";
                    Pattern pattern = Pattern.compile(regex);

                    // Recorrer cada línea (producto) del texto de la devolución
                    for (String linea : lineas) {
                        Matcher matcher = pattern.matcher(linea);
                        if (matcher.find()) {
                            String codigo = matcher.group(1);
                            int cantidadVendida = Integer.parseInt(matcher.group(2));
                            int cantidadADevolver = Integer.parseInt(matcher.group(3));

                            // Obtener el precio del producto en base al código del producto
                            Producto producto = Tiendita.BuscarProducto(codigo);
                            if (producto != null) {
                                double precio = producto.getPrecioP(); // Obtener el precio del producto
                                double precioTotalPorProducto = precio * cantidadADevolver;
                                precioTotalDevolucion += precioTotalPorProducto;
                                int existenciaActual = producto.getExistenciaP();
                                producto.setExistenciaP(existenciaActual + cantidadADevolver);

                            }
                        } else {
                            System.err.println("Error: formato incorrecto en la línea \"" + linea + "\"");
                        }
                    }

                    // Mostrar el precio total en un JOptionPane
                    JOptionPane.showMessageDialog(menu.this, "El precio total de la devolución es: " + precioTotalDevolucion, "Precio Total Devolución", JOptionPane.INFORMATION_MESSAGE);
                    Tiendita.setSaldo(Tiendita.getSaldo() - precioTotalDevolucion);
                    totalSaldo.setText(String.valueOf(Tiendita.getSaldo()));
                    manejoArchivo.escri(Tiendita.getProductolista(),Tiendita.getProductosFile());
                    manejoArchivo.escribirDevolucion(Tiendita.getDevolFile(), textoDevolucion, precioTotalDevolucion);
                    textAreaDevolucion.setText("");
                    labelfechayhora.setText("AAAA-MM-DD HH:MM:SS");
                }else{
                    JOptionPane.showMessageDialog(menu.this, "No se seleccionó ningún producto", "Error al procesar la devolución", JOptionPane.ERROR_MESSAGE);
                    textAreaDevolucion.setText("");
                    labelfechayhora.setText("AAAA-MM-DD HH:MM:SS");
                }
                }

        });

        agregarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String codigo = codigoVenta.getText();
                    String nombre = comboBox1.getSelectedItem().toString();
                    String cant = cantidadVenta.getText();
                    int canti = Integer.parseInt(cant);
                    if ((Tiendita.BuscarProducto(codigo)).getExistenciaP() >= canti) {
                        nombre = (Tiendita.BuscarProducto(codigo)).getNombreP();
                        double cantidad = Double.parseDouble(cant);
                        double precio = Tiendita.BuscarProducto(codigo).getPrecioP();
                        double totalPrecio = precio * cantidad;
                        totalVenta += totalPrecio;
                        InfoVenta.append("\nProducto: " + nombre + " " + "Codigo: " + codigo + " ");
                        InfoVenta.append("Cantidad: " + cant + " " + "Precio: " + " " + totalPrecio + "\n");
                        codigoVenta.setText("");
                        cantidadVenta.setText("");
                        TotalPRecio.setText(String.valueOf(totalVenta));
                    } else {
                        JOptionPane.showMessageDialog(null, "La cantidad ingresada no es valida.");
                    }
                }catch(Exception l){
                    JOptionPane error= new JOptionPane("Por favor rellene correctamente los espacios.", JOptionPane.ERROR_MESSAGE);
                    JDialog mensajeError = error.createDialog(menu.this,"Error al agregar producto");
                    mensajeError.setVisible(true);
                    mensajeError.setModal(true);
                    mensajeError.setAlwaysOnTop(true);
                }
            }
        });

        comboBox1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ProductoVenta pr = (ProductoVenta) comboBox1.getSelectedItem();
                if (pr != null){
                    codigoVenta.setText(pr.getCodigoP());
                }
            }
        });

        actualizarInventarioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                paneInventario.setText(Tiendita.showProductos(Tiendita.getProductolista()));
                highlightText(paneInventario, "Productos sin stock:", Color.RED);
                comboBox1.setModel(new DefaultComboBoxModel(prod.toArray()));
            }
        });
//////////////*
        agregarFechaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Verificar si los campos de texto están vacíos
                if (textFieldFechaD.getText().isEmpty() || textFieldHoraD.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(menu.this, "Rellene los espacios vacíos", "Error al ingresar fecha", JOptionPane.ERROR_MESSAGE);
                } else {
                    String fecha = textFieldFechaD.getText();
                    String hora = textFieldHoraD.getText();
                    String fechaTotal = fecha.trim() + " " + hora.trim();

                    // Validar el formato de la fecha y hora
                    if (!isValidDateFormat(fecha, "yyyy-MM-dd")) {
                        JOptionPane.showMessageDialog(menu.this, "Formato de fecha inválido. Por favor, ingrese la fecha en formato AAAA-MM-DD.", "Error", JOptionPane.ERROR_MESSAGE);
                        textFieldHoraD.setText("");
                        textFieldHoraD.setText("");
                        return;
                    }

                    if (!isValidDateFormat(hora, "HH:mm:ss")) {
                        JOptionPane.showMessageDialog(menu.this, "Formato de hora inválido. Por favor, ingrese la hora en formato HH:MM:SS.", "Error", JOptionPane.ERROR_MESSAGE);
                        textFieldHoraD.setText("");
                        textFieldHoraD.setText("");
                        return;
                    }

                    // Buscar la venta por fecha y hora
                    String venta = manejoArchivo.buscarVentaPorFechaYHora(Tiendita.getVentasFile(), fechaTotal);
                    if (!venta.isEmpty()) {
                        JOptionPane.showMessageDialog(menu.this, "Los datos coinciden con una venta", "Fecha encontrada con éxito", JOptionPane.INFORMATION_MESSAGE);
                        textFieldHoraD.setText("");
                        textFieldHoraD.setText("");
                        labelfechayhora.setText(fechaTotal);
                    } else {
                        JOptionPane.showMessageDialog(menu.this, "La fecha ingresada no coincide con ninguna venta, favor de revisar los datos", "Error", JOptionPane.ERROR_MESSAGE);
                        textFieldHoraD.setText("");
                        textFieldHoraD.setText("");
                    }
                }
            }
        });

        //////////////////
        ActualizarButtonCorte.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Color colorOriginal = corteTotal.getForeground();
                LocalDate today = LocalDate.now();
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                String fechaHoy = today.format(formatter);

                // Obtener las ventas y devoluciones de hoy y mostrarlas
                String fileVenta = Tiendita.getVentasFile();
                String fileDevol = Tiendita.getDevolFile();
                lista<String> ventasDeHoy = manejoArchivo.buscarVentasPorFecha(fileVenta, fechaHoy);
                lista<String> devolucionesDeHoy = manejoArchivo.buscarDevolucionesPorFecha(fileDevol, fechaHoy);
                if(ventasDeHoy.getTamanio() == 0 && devolucionesDeHoy.getTamanio() == 0){
                    JOptionPane.showMessageDialog(menu.this,"No se han registrado operaciones el día de hoy" ,"Error al cargar operaciones", JOptionPane.INFORMATION_MESSAGE);
                }else {
                    // Limpiar las áreas de texto antes de agregar los nuevos datos
                    ventaCortetext.setText("");
                    devolCorteText.setText("");

                    for (int i = 0; i < ventasDeHoy.getTamanio(); i++) {
                        ventaCortetext.append(ventasDeHoy.obtener(i) + "\n");
                    }

                    // Mostrar las devoluciones de hoy
                    for (int i = 0; i < devolucionesDeHoy.getTamanio(); i++) {
                        devolCorteText.append(devolucionesDeHoy.obtener(i) + "\n");
                    }
                    double totalVentas = calcularTotal(ventasDeHoy);
                    double totalDevoluciones = calcularTotal(devolucionesDeHoy);
                     corteTotalDev.setText("$" + totalDevoluciones);
                    corteTotalVentas.setText("$" + totalVentas);
                    if (ventasDeHoy.getTamanio() == 0) {
                        ventaCortetext.setText("No se han registrado ventas");
                        corteTotalVentas.setText("$0.0");
                    }
                    if (devolucionesDeHoy.getTamanio() == 0) {
                        devolCorteText.setText("No se han registrado devoluciones");
                        corteTotalDev.setText("$0.0");
                    }
                    double corteTotalO = totalVentas - totalDevoluciones+1000;
                    corteTotal.setText(String.valueOf(corteTotalO));
                    if(corteTotalO < 0){
                        corteTotal.setForeground(Color.RED);
                    } else {
                        corteTotal.setForeground(original);
                    }
                }
            }
        });
    }

    private void verificarWebcam() {
        // Intenta obtener la webcam
        webcam = Webcam.getDefault();
        if (webcam == null) {
            // Si no se detecta ninguna webcam, desactiva el botón y muestra el mensaje
            botonCam.setEnabled(false);
            // Agrega un label al centro del panelCam
            JLabel noWebcamLabel = new JLabel("No se detectó ninguna webcam.", SwingConstants.CENTER);
            noWebcamLabel.setForeground(Color.WHITE);
            panelCam.add(noWebcamLabel, BorderLayout.CENTER);
            panelCam.revalidate();
            panelCam.repaint();
        } else {
            webcam.setCustomViewSizes(new Dimension[] { WebcamResolution.HD.getSize(), WebcamResolution.FHD.getSize() }); // Establecer resoluciones HD y Full HD
            webcam.setViewSize(WebcamResolution.FHD.getSize()); // Seleccionar la resolución Full HD

            // Si se detecta una webcam, el botón permanece habilitado
            botonCam.setEnabled(true);
        }
    }


    private void finalizarVenta(String texto, String clienteInfo) {
        manejoArchivo.escribirVenta(Tiendita.getVentasFile(), texto, totalVenta, clienteInfo);
        manejoArchivo.escriCliente(Tiendita.getClienteslista(), Tiendita.getClientesFile());
        InfoVenta.setText("");
        TotalPRecio.setText("");
        Tiendita.setSaldo(Tiendita.getSaldo() + totalVenta);
        manejoArchivo.escri(Tiendita.getProductolista(), "Productos.txt");
        totalSaldo.setText(String.valueOf(Tiendita.getSaldo()));
        totalVenta = 0;
    }

    private static class NoNada extends javax.swing.text.PlainDocument {
        @Override
        public void insertString(int offs, String str, AttributeSet a) throws BadLocationException {
            if (str != null && !str.matches(".*[a-zA-Z].*") &&!str.matches(".*[^a-zA-Z0-9\\s].*")) {
                super.insertString(offs, str, a);
            }
        }
    }
    private static class onlyLetras extends javax.swing.text.PlainDocument {
        @Override
        public void insertString(int offs, String str, AttributeSet a) throws BadLocationException {
            if (str != null && !str.matches(".*[^a-zA-Z\\s].*")) {
                super.insertString(offs, str, a);
            }
        }
    }
    private static class onlyNumbs extends javax.swing.text.PlainDocument {
        @Override
        public void insertString(int offs, String str, AttributeSet a) throws BadLocationException {
            if (str != null && !str.matches(".*[a-zA-Z].*") && !str.contains(" ") && !str.matches(".*[^a-zA-Z0-9].*")) {
                super.insertString(offs, str, a);
            }
        }
    }
    private void iniciarReloj() {
        Thread hiloReloj = new Thread(new Runnable() {
            public void run() {
                while (true) {
                    actualizarHora();
                    try {
                        Thread.sleep(1000); // Pausar el hilo por 1 segundo
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        hiloReloj.start();
    }
    private static void highlightText(JTextPane textPane, String textToHighlight, Color color) {
        try {
            // Obtener el documento del JTextPane
            StyledDocument doc = textPane.getStyledDocument();

            // Crear un estilo para el texto resaltado
            SimpleAttributeSet highlightStyle = new SimpleAttributeSet();
            StyleConstants.setForeground(highlightStyle, color);

            // Obtener el contenido del JTextPane
            String content = textPane.getText();

            // Encontrar la posición del texto a resaltar
            int start = content.indexOf(textToHighlight);
            if (start >= 0) {
                // Aplicar el estilo solo al texto resaltado
                doc.setCharacterAttributes(start, textToHighlight.length(), highlightStyle, false);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    // Método para actualizar la hora en el JLabel
    private void actualizarHora() {
        SimpleDateFormat formatoHora = new SimpleDateFormat("HH:mm:ss" + "  ");
        final String horaActual = formatoHora.format(new Date());
        // Actualizar el JLabel en el hilo de despacho de eventos de Swing
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                reloj.setText(horaActual);
            }
        });
    }
    private boolean isValidDateFormat(String value, String format) {
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        sdf.setLenient(false); // Para que sea estricto en el análisis de la fecha
        try {
            sdf.parse(value);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    public static boolean EsNumeroEntero(String valor) {
        try {
            int d = Integer.parseInt(valor);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }

    public static boolean EsNumero(String valor) {
        try {
            double d = Double.parseDouble(valor);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }

    private double calcularTotal(lista<String> operaciones) {
        if (operaciones.isEmpty()) {
            return 0;
        }

        double total = 0;
        for (int j = 0; j < operaciones.getTamanio(); j++) {
            String operacion = operaciones.obtener(j);
            String[] lineas = operacion.split("\n");
            for (int i = 0; i < lineas.length; i++) {
                if (lineas[i].startsWith("Total:")) {
                    total += Double.parseDouble(lineas[i].substring(7).trim());
                    break;
                }
            }
        }
        return total;
    }
}
